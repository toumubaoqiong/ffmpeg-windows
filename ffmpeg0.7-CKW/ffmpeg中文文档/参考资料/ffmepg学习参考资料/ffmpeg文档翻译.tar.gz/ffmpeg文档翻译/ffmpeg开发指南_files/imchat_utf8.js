﻿function IMHashtable(){
    this._hash = new Object();  /* 创建Object对象*/
    this.add = function(key,value){
        if(typeof(key)!="undefined"){
            if(this.contains(key)==false){
                this._hash[key]=typeof(value)=="undefined"?null:value;
                return true;
            }else {
                return false;
            }
        }else {
            return false;
        }
    }
    this.remove = function(key){delete this._hash[key];}
    this.count = function(){var i=0;for(var k in this._hash){i++;} return i;}
    this.items = function(key){return this._hash[key];}
    this.contains  = function(key){ return typeof(this._hash[key])!= "undefined";}
    this.clear = function(){for(var k in this._hash){delete this._hash[k];}}
}

IMNotifyManager = function(){/*sum of all notify window height*/
    this._currentNotifyWndHeight = 0;
    this._notifyWnds = new IMHashtable();
};
_p = IMNotifyManager.prototype;
_p.addAnimateNotifyWnd = function(divid, div, isautohide)
{
    var clientRect = im_wdkUtil.viewRect.get(window, true);
    animateInitY = clientRect.y+clientRect.h-this._currentNotifyWndHeight;
    div.style.top = animateInitY+"px";
    div.style.left = "";
    div.style.right = "10px";
    div.style.display = "inline";
    div.bShow = true;

    divh = im_wdkUtil.viewRect.getH(div);
    this._currentNotifyWndHeight += divh;

    var newWnd = new Object();
    newWnd.divid = divid;
    newWnd.div = div;
    newWnd.desty = animateInitY-divh-40;
    newWnd.currenty = animateInitY;
    newWnd.isautohide = isautohide;
    newWnd.timerid = 0;
    newWnd.autohidey = animateInitY;
    this._notifyWnds.add(divid, newWnd);
    this.animate(divid, isautohide);
}
_p.removeAnimateNotifyWnd = function(divid){
    var msgdiv = document.getElementById(divid);
    if(msgdiv){
        msgdiv.style.display = "none";
        msgdiv.parentNode.removeChild(msgdiv);
        divh = im_wdkUtil.viewRect.getH(msgdiv);
        this._currentNotifyWndHeight -= divh;
    }
}
_p.getNotifyWnd = function(divid){
    return this._notifyWnds.items(divid);
}
_p.getAnimatePos = function(){
}
_p.animate = function(divid, isautohide) {
    var currentWnd = this.getNotifyWnd(divid);
    var div = document.getElementById(divid);
    if(!currentWnd.isautohide)
        isautohidestr = "false";
    else
        isautohidestr = "true";
    __thisObject = this;
    if (currentWnd.currenty != currentWnd.desty ) {
        var step = Math.abs(currentWnd.desty-currentWnd.currenty)>10 ? 10: Math.abs(currentWnd.desty-currentWnd.currenty);
        currentWnd.currenty += currentWnd.desty < currentWnd.currenty ? -(step) : step;
        var px = currentWnd.currenty + "px";
        if(div)
            div.style.top = px;
        clearTimeout(currentWnd.timerid);
        timeoutfuncstr = "__thisObject.animate('"+divid+"',"+isautohidestr+")";
        currentWnd.timerid = setTimeout(timeoutfuncstr, 33);
    } else {
        if(div){
            div.style.top = currentWnd.desty;
            if(div.bShow == false){
                div.style.display = "none";
                divh = im_wdkUtil.viewRect.getH(div);
                this._currentNotifyWndHeight -= divh;
                __thisObject.removeAnimateNotifyWnd(divid);
            }
        }
        clearTimeout(currentWnd.timerid);
        if(div && div.bShow==true && isautohide){
            div.bShow = false;
            currentWnd.desty = currentWnd.autohidey;
            timeoutfuncstr = "__thisObject.animate('"+divid+"',"+isautohidestr+")";
            currentWnd.timerid = setTimeout(timeoutfuncstr, 10000);
        }
    }
}

IMNotifyWindow = function(type){
    this.contentHtml = "";
    this.msgArray = new Array();
    this.notifyDivID = "";
    this.notifyDiv = null;
    this.notifyNextBtnID = "imnotify_next_btn";
    this.notifyPrevBtnID = "imnotify_prev_btn";
    this.pageSpanID      = "imnotify_page_span";
    this.notifyPrevBtn = null;
    this.notifyNextBtn = null;
    this.curNotiyIndex = null; 
}
_p = IMNotifyWindow.prototype;
_p.addMessage = function(destuid, destname, message, chatid, logoUrl){
    for(var i=0; i<this.msgArray.length; i++){
        if(this.msgArray[i].destuid==destuid)
            return;
    }
    var newMsg = new Object()
    newMsg.destuid  = destuid;
    newMsg.destname = destname;
    newMsg.message  = message;
    newMsg.chatid   = chatid;
    newMsg.logourl  = logoUrl;
    this.msgArray.push(newMsg);
    if(this.msgArray.length==1){
        this.curNotifyIndex = 0;
        this.showNotify(newMsg, true);
    }
    this.setNextPrevStatus();
}
_p.setNextPrevStatus = function(){
    if(this.msgArray.length>(this.curNotifyIndex+1))
        this.enableLink(this.notifyNextBtn);
    else
        this.disableLink(this.notifyNextBtn);
    
    if(this.curNotifyIndex>0)
        this.enableLink(this.notifyPrevBtn);
    else
        this.disableLink(this.notifyPrevBtn);
    
    this.pageSpan.innerHTML = (this.curNotifyIndex+1)+"/"+this.msgArray.length;
}
_p.removeNotify = function(){
    this.msgArray.splice(this.curNotifyIndex,1);
    if(this.msgArray.length==0){
        this.closeNotifyWindow();
        return;
    }
    else{ 
        if(this.msgArray.length==1)
            this.curNotifyIndex=0;
        else{
            if(this.curNotifyIndex==this.msgArray.length)
                this.curNotifyIndex--;
        }
        this.showNotify(this.msgArray[this.curNotifyIndex], false);
        this.setNextPrevStatus();
    }
}
_p.closeNotifyWindow = function(){
    this.msgArray = new Array();
    this.curNotifyIndex = null;
    im_notify_manager.removeAnimateNotifyWnd(this.notifyDivID);
}
_p.showNotify = function(newMsg, isNewWindow){
    if(isNewWindow){
        this.notifyDiv = im_wdkUtil.createDom({name:"DIV",id:this.notifyDivID,style:"position:absolute;z-index:111111;display:none;"});
    }
    var msgdivstr = this.getMsgDivStr(newMsg, isNewWindow);
    this.notifyDiv.innerHTML = msgdivstr;
    this.notifyNextBtn = document.getElementById(this.notifyNextBtnID);
    this.notifyPrevBtn = document.getElementById(this.notifyPrevBtnID);
    this.pageSpan = document.getElementById(this.pageSpanID);
    if(isNewWindow){
        im_notify_manager.addAnimateNotifyWnd(this.notifyDivID, this.notifyDiv, false);
    }
}
_p.disableLink = function(linkNode){
   linkNode.removeAttribute("href");
   linkNode.style.color="gray";
   linkNode.style.textDecoration="none";
}
_p.enableLink = function(linkNode){
   linkNode.setAttribute("href","#");
   linkNode.style.color="";
   linkNode.style.textDecoration="underline";
}
_p.prevNotify = function(){
    if(this.curNotifyIndex>0){
       this.curNotifyIndex--;
       this.showNotify(this.msgArray[this.curNotifyIndex], false);
       this.setNextPrevStatus();
    }
}
_p.nextNotify = function(){
    if((this.curNotifyIndex+1)<this.msgArray.length){
       this.curNotifyIndex++;
       this.showNotify(this.msgArray[this.curNotifyIndex], false);
       this.setNextPrevStatus();
    }
}

IMMsgNotifyWindow = function(destuid, destname, message,chatid){
    IMNotifyWindow.prototype.constructor();
    this.notifyDivID = "im_instant_notify_div";
}

IMMsgNotifyWindow.prototype = new IMNotifyWindow();
_p = IMMsgNotifyWindow.prototype;
_p.getMsgDivStr = function(newMsg, isNewWindow){
    if(newMsg.message && newMsg.message.length>15)
        newMsg.message = newMsg.message.substring(0,15)+"...";
    var userLogoUrl = newMsg.logourl ? newMsg.logourl : im_global.cache.img["notify_userhead"].src;
    var viewMsg = im_global.cfg.customparams["entrytype"]=='toolbar' ? true : false;
    var msgdivstr =
        "<table width='180' height='100' border='0' cellpadding='0' cellspacing='0' style='background-color:#FFF;border:1px solid #707070;' >"
        + "<tr>"
        +   "<td valign='top'>"
        +     "<table width='99%' border='0' cellpadding='0' cellspacing='0' background='"+im_global.cache.source+"notify_bj.jpg'>"
        +      "<tr>"
        +        "<td width='20%' height='25' style='font-size:12px;color:#FFF;'><span stype=margin-lfet:5px;>提示</span></td>"
        +        "<td width='50%' style='font-size:12px;-moz-user-select: none;-khtml-user-select: none;user-select: none;'></td>"
        +        "<td width='30%' align='right' style='text-align:right;'>"
        +          "<a style='font-size:12px;color:#FFF;cursor:pointer;' onClick=\"javascript: im_msgNotifyWindow.closeNotifyWindow();"+(viewMsg ? "im_toolbar._viewMsg('all', 2, false);" : "")+" return false;\">全部忽略</a>"
        +        "</td>"
        +      "</tr>"
        +   "</table>"
        +   "<table width='95%' height='50' border='0' align='left' cellpadding='1'>"
        +      "<tr>"
        +        "<td width='30%'><img src='"+userLogoUrl+"' width='40' height='40'  border='0' vspace='5' /></td>"
        +        "<td width='70%'>"
        +          "<div align='left' style='font-size:12px;color:#00F;'>"+newMsg.destname+"说：</div>"
        +          "<div align='left' style='font-size:12px;color:#000;'>"+newMsg.message+"</div>"
        +        "</td>"
        +      "</tr>"
        +      "<tr>"
        +        "<td width='30%'></td>"
        +        "<td width='70%'>"
        +          "<div align='center'>"
        +            "<a style=\"font-size:12px;cursor:pointer;\" onClick=\"javascript: im_openWebchatWindow('" + newMsg.destuid + "','"+newMsg.destname+"');"+(viewMsg ? "im_toolbar._viewMsg('"+newMsg.destuid+"', 2);" : "")+"im_msgNotifyWindow.removeNotify('"+newMsg.destuid+"');return false;\">"
        +               "<img src='"+im_global.cache.source+"notify_jieshou.gif'  border='0' hspace='3' vspace='3' />"
        +            "</a>"
        +            "<a style=\"font-size:12px;cursor:pointer;\" onClick=\"im_msgNotifyWindow.removeNotify('"+newMsg.destuid+"');"+(viewMsg ? "im_toolbar._viewMsg('"+newMsg.destuid+"', 2, false);" : "")+"return false;\">"
        +               "<img src='"+im_global.cache.source+"notify_hulue.gif'  border='0' hspace='3' vspace='3' />"
        +            "</a>"
        +          "</div>"
        +          "<div align='center'>"
        +            "<a style=\"font-size:12px;cursor:pointer;\" id=\""+this.notifyPrevBtnID+"\" onClick=\"javascript: im_msgNotifyWindow.prevNotify('"+newMsg.destuid+"'); return false;\">"
        +              "上一条"
        +            "</a> "
        +            "<span id=\""+this.pageSpanID+"\"></span>"
        +            " <a style=\"font-size:12px;cursor:pointer;\" id=\""+this.notifyNextBtnID+"\" onClick=\"javascript: im_msgNotifyWindow.nextNotify('"+newMsg.destuid+"'); return false;\">"
        +              "下一条"
        +            "</a>"
        +          "</div>"
        +        "</td>"
        +      "</tr>";
        +    "</table>"
        +   "</td>"
        + "</tr>"
        +"</table>";
    try{
        return msgdivstr;
    }finally{
        msgdivstr = null;
    }
}

var im_msgNotifyWindow = null;
IMOfflineMsgNotifyWindow = function(destuid, destname, message,chatid){/**/
    IMNotifyWindow.prototype.constructor();
    this.notifyDivID = "im_offline_notify_div";
}

IMOfflineMsgNotifyWindow.prototype = new IMNotifyWindow();
_p = IMOfflineMsgNotifyWindow.prototype;
_p.getMsgDivStr = function(newMsg, isNewWindow){
    if(newMsg.message && newMsg.message.length>15)
        newMsg.message = newMsg.message.substring(0,15)+"...";
    var userLogoUrl = newMsg.logourl ? newMsg.logourl : im_global.cache.img["notify_userhead"].src;
    var viewMsg = im_global.cfg.customparams["entrytype"]=='toolbar' ? true : false;
    var msgdivstr =
        "<table width='180' height='100' border='0' cellpadding='0' cellspacing='0' style='border:1px solid #707070;'>"
        + "<tr><td valign='top' background='"+im_global.cache.source+"notify_bodybj.jpg'>"
        +    "<table width='99%' border='0' cellpadding='0' cellspacing='0'>"
        +      "<tr>"
        +        "<td width='11%' height='25' style='font-size:12px;'><img src='"+im_title_logo.src+"' width='19' height='16' hspace='8' /></td>"
        +        "<td width='70%' style='font-size:12px;-moz-user-select: none;-khtml-user-select: none;user-select: none;'>"+destname+"发送的离线消息</td>"
        +        "<td width='19%' align='right'>"
        +          "<a style=\"font-size:12px;cursor:pointer;\" onClick=\"javascript: im_offlineMsgNotifyWindow.removeNotify('" +destuid+ "'); return false;\"><img src='"+im_global.cache.source+"notify_close.gif' width='7' border='0' height='7' /></a>"
        +        "</td>"
        +      "</tr>"
        +      "<tr>"
        +        "<td height='30' colspan='3' align='center' style='font-size:12px;color:#333;'>"+destname+"说："+message+"</td>"
        +      "</tr>"
        +      "<tr>"
        +        "<td height='20' colspan='3' align='center'>"
        +          "<a style=\"font-size:12px;cursor:pointer;\" onClick=\"javascript: im_openWebchatWindow('" + destuid + "','"+destname+"');"+(viewMsg ? "im_toolbar._viewMsg('"+newMsg.destuid+"', 2);" : "")+" im_offlineMsgNotifyWindow.removeNotify('"+destuid+"');return false;\"><img src='"+im_global.cache.source+"notify_kslt.gif' width='59' height='30' border='0' hspace='5' vspace='5' /></a>"
        +          "<a style=\"font-size:12px;cursor:pointer;display:"+nextButtonStype+"; margin-left:5px\" id=\""+this.notifyNextBtnID+"\" onClick=\"javascript: im_offlineMsgNotifyWindow.removeNotify('"+destuid+"'); return false;\">下一个</a>"
        +      "</td></tr>"
        +    "</table>"
        +  "</td></tr>"
        +"</table>";
    try{
        return msgdivstr;
    }finally{
        msgdivstr = null;
    }
}

var im_offlineMsgNotifyWindow = null;
/*called by presence flash*/
function presenceSetMyClientID(flashGoUrl){
    var str = "";
    im_global.temp.presenceFlashGoUrl = flashGoUrl;
}
function presenceSetIMSid(imsid){
    var str = "";
    im_global.variable.imsid = imsid;
}
function im_openWebchatInPage(destuid, destname, chatid){
    return im_chat_window_manager.addChatWindow(destuid, destname, chatid, true, null);
}

function im_onBeforeUnload(ev){
  if(im_global.variable.user_id && im_chat_window_manager && im_chat_window_manager._chatWndsArray.length>0){
    /*for(var k in im_chat_window_manager._chatWnds._hash){
      chatWindow = im_chat_window_manager._chatWnds._hash[k];
      break;
    }*/
    chatWindow = im_chat_window_manager._chatWndsArray[0];
    if(typeof(chatWindow)!="undefined" && chatWindow){
      var confirmText = "您目前正在与"+chatWindow._destnick+"等进行实时对话，确定关闭对话吗？";
      ev = ev || window.event;
      ev.returnValue = confirmText;
      return;
    }
  }
}

function im_onUnload(){
    var flashobj = document.getElementById("impresenceflash");
    if(flashobj){
        if(flashobj.closePresence)
            flashobj.closePresence();
        im_wdkUtil.disposeFlashObj(flashobj);
        flashobj.parentNode.removeChild(flashobj);
    }

    if(im_global.temp.presenceFlashGoUrl){
        im_wdkUtil.createScript(im_global.temp.presenceFlashGoUrl);
    }
    if(im_global.temp.buddylistFlashGoUrl){
        im_wdkUtil.createScript(im_global.temp.buddylistFlashGoUrl);
    }
    
    /*dzy */
    im_wdkUtil.Event.flush();
    
    if(im_global.cfg.customparams["entrytype"]=='toolbar' && im_toolbar)
        im_toolbar.saveMsg();
    if(im_chat_window_manager)
        im_chat_window_manager.closeAll();
    if(im_myIMWindow)
        im_myIMWindow.close();
    if(im_global.cfg.DebugType==2)
        dzy_debug.dispose();
}

/*处理pressence flash收到消息的回调函数*/
function OnPresenceReceiveChatMsg(destuid, destnick, wid, flashserver, message, chatid, isNotify, isMyFriend, isOnlineMsg, logoUrl){
    if(im_global.cfg.DebugType==2){
        if(isMyFriend==-1)
            dzy_debug.debug("陌生人消息:"+message+", 通知:isNotify="+isNotify+", 在线消息:"+isOnlineMsg);
        else if(isMyFriend==1)
            dzy_debug.debug("自已的消息:"+message+", 通知:isNotify="+isNotify+", 在线消息:"+isOnlineMsg);
        else if(isMyFriend==2)
            dzy_debug.debug("好友消息:"+message+", 通知:isNotify="+isNotify+", 在线消息:"+isOnlineMsg);
        else if(isMyFriend==3)
            dzy_debug.debug("非法用户消息:"+message+", 通知:isNotify="+isNotify+", 在线消息:"+isOnlineMsg);
    }
    
    if((isNotify && isMyFriend!=2) || im_global.cfg.customparams["alway_notify"]){/*isMyFriend[-1:陌生人|1:自已|2:好友|3:非法用户]*/
        if(im_global.cfg.customparams["entrytype"]=="toolbar"){
            im_toolbar.addMsg(destuid, destnick, destnick+"请求跟你对话",2, chatid, isNotify, message);
        }
        if(isOnlineMsg){
            if(!im_msgNotifyWindow)
                im_msgNotifyWindow = new IMMsgNotifyWindow();
            im_msgNotifyWindow.addMessage(destuid, destnick, message, chatid, logoUrl);
        }
        else{
            if(!im_offlineMsgNotifyWindow)
                im_offlineMsgNotifyWindow = new IMOfflineMsgNotifyWindow();
            im_offlineMsgNotifyWindow.addMessage(destuid, destnick, message, chatid, logoUrl);
        }
    }
    else{
        im_chat_window_manager.addChatWindow(destuid, destnick, chatid, false, message);/**/
    }
    if(promptwindow)
         promptwindow.startPrompt(destnick+"请求跟你对话", true);
    return true;
}

function OnPresenceReceiveAddFriend(destuid, destnick, isViewMsg){//, userhead
    if(!isViewMsg && im_global.cfg.customparams["entrytype"]=='toolbar') im_toolbar.addMsg(destuid, destnick, destnick + "加您为好友", 1);
    
    im_global.temp.notify_id++;
    notifydivid = "im_user_add_friend_"+im_global.temp.notify_id;
    
    var msgdiv = im_wdkUtil.createDom({name:"div",id:notifydivid,style:"position:absolute;z-index:111111;display:none;"});
    var msgdivstr =
    "<table width='180' height='100' border='0' cellpadding='0' cellspacing='0' style='border:1px solid #707070;'>"
    + "<tr><td valign='top' background='"+im_global.cache.source+"notify_bodybj.jpg'>"
    +    "<table width='99%' border='0' cellpadding='0' cellspacing='0'>"
    +      "<tr>"
    +        "<td width='11%' height='25' style='font-size:12px;'><img src='"+im_global.cache.img["im_logo"].src+"' width='" + im_global.cache.img["im_logo"].width + "' height='16' hspace='8' /></td>"
    +        "<td width='70%' style='font-size:12px;-moz-user-select: none;-khtml-user-select: none;user-select: none;'>系统消息</td>"
    +        "<td width='19%' align='right'>"
    +          "<a style=\"font-size:12px;cursor:pointer;\" onClick=\"javascript: im_notify_manager.removeAnimateNotifyWnd('" + notifydivid + "'); return false;\"><img src='"+im_global.cache.source+"notify_close.gif' width='7' border='0' height='7' /></a>"
    +        "</td>"
    +      "</tr>"
    +      "<tr>"
    +        "<td height='30' colspan='3' align='center' style='font-size:12px;color:#333;'>"+destnick+"加你为好友</td>"
    +      "</tr>"
    +      "<tr>"
    +        "<td height='20' colspan='3' align='center'>"
    +          "<!--<img src='"+im_global.cache.source+"notify_addfriend.gif' width='55' height='25' hspace='5' vspace='5' />-->"
    +          "<a style=\"font-size:12px;cursor:pointer;\" onClick=\"javascript: im_openWebchatWindow('" + destuid + "','"+destnick+"');im_toolbar._viewMsg('" + destuid + "', 1); return false;\"><img src='"+im_global.cache.source+"notify_kslt.gif' width='55' height='25' border='0' hspace='5' vspace='5' /></a></td>"
    +      "</tr>"
    +    "</table>"
    +  "</td></tr>"
    +"</table>";
    msgdiv.innerHTML = msgdivstr;
    im_notify_manager.addAnimateNotifyWnd(notifydivid, msgdiv, true);
}


function OnPresenceReceiveUserOnline(destuid, destnick, logoUrl){
    //return;
    im_global.temp.notify_id++;
    notifydivid = "im_user_online_notify_"+im_global.temp.notify_id;
    
    var msgdiv = im_wdkUtil.createDom({name:"div",id:notifydivid,style:"position:absolute;z-index:111111;display:none;"});
    var msgdivstr =
      "<table width='180' height='85' border='0' cellpadding='0' cellspacing='0' style='background-color:#FFF;border:1px solid #707070;'>"
    + "<tr>"
    +  "<td valign='top'>"
    +   "<table width='99%' border='0' cellpadding='0' cellspacing='0' background='"+im_global.cache.source+"notify_bj.jpg'>"
    +     "<tr>"
    +       "<td width='20%' height='25' style='font-size:12px;color:#FFF;'><span stype=\"margin-lfet:5px;\">提示</span></td>"
    +       "<td width='65%' style='font-size:12px;-moz-user-select: none;-khtml-user-select: none;user-select: none;'></td>"
    +       "<td width='15%' align='right'>"
    +         "<a style=\"font-size:12px;cursor:pointer;margin-right:5px\" href=\"\" onClick=\"javascript: im_notify_manager.removeAnimateNotifyWnd('" + notifydivid + "'); return false;\"><img src='"+im_global.cache.source+"notify_close.gif' border='0' width='7' height='7' /></a>"
    +       "</td>"
    +     "</tr>"
    +   "</table>"
    +   "<table width='95%' height='50' border='0' align='center' cellpadding='1'>"
    +     "<tr>"
    +       "<td width='25%'>"
    +         "<img src='"+logoUrl+"' width='40' height='40'  border='0' vspace='5' /></a>"
    +       "</td>"
    +       "<td width='40%'><span style='font-size:12px;color:#000077;line-height:18px;'>"+destnick
    +                       "</span><br/><span  style='margin-top:5px;font-size:12px;color:#000000;line-height:15px;'>刚上线</span</td>"
    +       "<td width='35%' style='cursor:pointer;text-decoration:underline;font-size:12px;color:#000077;line-height:18px;' onclick=\"javascript: im_openWebchatWindow('" + destuid + "','"+destnick+"'); im_notify_manager.removeAnimateNotifyWnd('" + notifydivid + "'); return false;\"> <br/>在线聊天</td>"
    +     "</tr>"
    +   "</table>"
    +  "</td>"
    + "</tr>"
    + "</table>";
    msgdiv.innerHTML = msgdivstr;
    im_notify_manager.addAnimateNotifyWnd(notifydivid, msgdiv, true);
}


/*处理buddylistflash收到消息的回调函数,notifyoption,0: open new window, 1:notify message*/
function OnBuddylistReceiveChatMsg(destuid, destnick, wid, flashserver, message, notifyoption){
    /*alert("BuddylistReceiveChatMsg");*/
    /*if (notifyoption==1) {
        im_notify(destuid, destnick, message);
    } else {
        im_launch(destuid, destnick, message);
    }*/
}

function OnWebchatOpenAV(destuid, isVedio){
  return;
  var chatWindow = im_chat_window_manager.getChatWindow(destuid);
  if(chatWindow)
    chatWindow.openAV(isVedio);
}
function OnWebchatCloseAV(destuid, isVedio){
	return;
  var chatWindow = im_chat_window_manager.getChatWindow(destuid);
  if(chatWindow)
    chatWindow.closeAV(isVedio);
}
function OnWebchatOpenBuddylist(){
    if(im_myIMWindow)
        im_myIMWindow.showWindow(true);
}

function URLencode(_16) {
    return escape(_16).replace(/\+/g, "%2B").replace(/\"/g, "%22").replace(/\'/g, "%27").replace(/\//g, "%2F");
}

function im_notifyOnClickedNo(_1a) {

}

AjaxEngine = function(){
};
var _p = AjaxEngine.prototype;
_p._XMLHTTP_PROGIDS = ["Msxml2.XMLHTTP", "Microsoft.XMLHTTP", "Msxml2.XMLHTTP.4.0"];
_p.getXmlhttpObject = function(){
    var xmlhttp;
    if(typeof XMLHttpRequest != "undefined"){
        try{
            xmlhttp = new XMLHttpRequest();
            xmlhttp.overrideMimeType("text/xml");
            return xmlhttp;
        }catch(e){}
    }
    if(!xmlhttp){
        for(var i = 0; i < 3; ++i){
            var progid = this._XMLHTTP_PROGIDS[i];
            try{
                xmlhttp = new ActiveXObject(progid);
            }catch(e){
            }
            if(xmlhttp){
                this._XMLHTTP_PROGIDS = [progid];
                return xmlhttp;    /*break;*/
            }
        }
    }
    if(!xmlhttp){
        window.alert("XMLHTTP not available");
    }
    return xmlhttp;
};
_p.invoke = function(url, type, callback){
    try{
        var http = this.getXmlhttpObject();
        var async = callback ? true : false;
        http.open("GET", url, async);
        if(async){
            http.onreadystatechange = function(){
                if(http.readyState == 4){
                    var o;
                    switch(type){
                    case "text":
                        o = http.responseText;
                        break;
                    case "xml":
                    default:
                        o = http.responseXML;
                        break;
                    }
                    callback(o);
                }
            };
        }
        http.send("");
        if(async){
            return;
        }else{
            /*http.readyState*/
            /*http.status*/
            if(http.readyState != 4){
                window.alert("资源文件加载失败");
                return;
            }else{
                /*code = Bytes2BStr(http.responseBody);*/
                    switch(type){
                    case "text":
                        return http.responseText;
                    case "xml":
                    default:
                        return http.responseXML;
                    }
            }
        }
    }catch(e){
        var s = "";
        for(var id in e){
            s += "\n" + id + "=" + e[id];
        }
        /*window.alert(s);*/
        return;
    }
};

var _s, _p;
var WDK_IM_PACK = {};

/**
 * class WDK_IM_PACK.Application
 */
WDK_IM_PACK.Application = function(){
    this._version = "3.0";
    this._debug = false;
    this._window = window;
    this._doc = this._window.document;
    this._body = null;
    this._FloatWindowManager = null;
};
_p = WDK_IM_PACK.Application.prototype;
_p.init = function(){
    this._FloatWindowManager = new WDK_IM_PACK.FloatWindowManager();
    this._FloatWindowManager.init();
};
_p.dispose = function(){
    this._FloatWindowManager.dispose();
    delete this._FloatWindowManager;
};
_p.createFlash = function(parent, id, src, title, w, h, mode){
    mode = mode ? mode:"Opaque";
    var obj;
    /*var loadingDiv = document.createElement("div");*/
    /*loadingDiv.appendChild(document.createTextNode("正在加载中..."));*/
    /*if(parent) parent.appendChild(loadingDiv);*/
    if(im_wdkUtil.Browser.msie){
        obj = this._doc.createElement("OBJECT");
        obj.setAttribute("classid", "clsid:d27cdb6e-ae6d-11cf-96b8-444553540000");
        obj.setAttribute("codeBase", "http://fpdownload.macromedia.com/get/flashplayer/current/swflash.cab");
        obj.setAttribute("movie", src);
    }else{
        obj = this._doc.createElement("EMBED");
        obj.setAttribute("src", src);
        obj.setAttribute("type", "application/x-shockwave-flash");
        obj.setAttribute("pluginspage","http://www.adobe.com/go/getflashplayer");
        obj.setAttribute("quality", "high");
    }
    obj.setAttribute("id", id);
    obj.setAttribute("name", id);
    obj.setAttribute("title", title);
    obj.setAttribute("width", w);
    obj.setAttribute("height", h);
    obj.style.width = w + "px";
    obj.style.height = h + "px";
    obj.setAttribute("allowScriptAccess", "always");
    obj.setAttribute("wmode", mode);
    /*if(loadingDiv)*/
    /*    parent.removeChild(loadingDiv);*/
    if(obj){
        obj.style.display = "block";
        if(parent) parent.appendChild(obj);
    }else{
        var txt = "flash创建失败，请您确定浏览器设置允许播放flash，或刷新浏览器重试，如果仍然不能正常使用请重新安flash插件";
        var textNode = this._doc.createTextNode(txt);
        if(parent) parent.appendChild(textNode);
    }
    try{
        return obj;
    }finally{
        obj = null;
    }
};

/**
 * class WDK_IM_PACK.FloatWindow
 */
WDK_IM_PACK.FloatWindow = function(){
    this._top = 0;
    this._right = 0;
    this._bottom = 0;
    this._left = 0;
    this._width = 0;
    this._height = 0;
};
_p = WDK_IM_PACK.FloatWindow.prototype;
_p.FloatWindowManager = function(inFloatPos, inOffsetX, inOffsetY){
};
_p.moveTo = function(x, y){
};
_p.resize = function(w, h){
};
_p.fooRepos = function(){
};

/**
 * class WDK_IM_PACK.FloatWindowManager
 */
WDK_IM_PACK.FloatWindowManager = function(){
    this._window = window;
    this._doc = this._window.document;
    this._activeWindow = null;
    this._windows = [];
    this.dragWin = null;
    this.clientArea = null;
    this._panel = null;
    this.dragSx;
    this.dragSy;
    this.isDrag = 0;
    this.isCascadeMode = false;

    this.resizeWin = null;
    this.dir = "";
    this.resizeX;
    this.resizeY;
    this.isresize = 0;

    this._inHead = true;
};
_p = WDK_IM_PACK.FloatWindowManager.prototype;
_p.init = function(){
    if(!this._doc.body){
        this._doc.write("<body></body>");
        this._inHead = true;
    }else{
        this._inHead = false;
    }
    this._body = this._doc.documentElement.clientHeight == 0 ? this._doc.body : this._doc.documentElement;
    var _this = this;
    function __repos(ev){
        ev = ev || _this._window.event;
        for(var i = 0; i < _this._windows.length; i++){
            _this._windows[i].fooRepos(ev);
            if(ev.type=='scroll' && _this._windows[i]._flash && im_wdkUtil.Browser.mozilla){/*firefox*/
                if(im_global.temp.resetwintop[i] != true){
                    window.setTimeout("wdkApplication._FloatWindowManager.updateWindowPos("+i+", 1)", 1000);
                    im_global.temp.resetwintop[i] = true;
                }
            }
        }
        return;
    }
    im_wdkUtil.Event.addEvent(this._window, "resize", __repos);
    im_wdkUtil.Event.addEvent(this._window, "scroll", __repos);
};
_p.addWindow = function(win){
    for(var i = 0; i < this._windows.length; i++){
        if(this._windows[i] == win)
          return;
    }
    this._windows.push(win);
};
_p.removeWindow = function(win){
    for(var i = 0; i < this._windows.length; i++){
        if(this._windows[i] == win){
            this._windows.splice(i,1);
            break;
        }
    }
    if(this._windows.length==0 && this._reposTimerID){
        clearTimeout(this._reposTimerID);
        this._reposTimerID = null;
    }
};
_p.startMove = function(ev, win, isCascadeMode){
    if(isCascadeMode){
        this.isCascadeMode = true;
        this.dragSx = ev.clientX;
        this.dragSy = ev.clientY;
        im_chat_window_manager.startMove();
    }
    else{
        this.isCascadeMode = false;
        this.dragSx = win._self.offsetLeft - ev.clientX;
        this.dragSy = win._self.offsetTop - ev.clientY;
    }
    this.dragWin = win;
    this.isDrag = 1;
    if(im_wdkUtil.Browser.msie)
        win._self.setCapture();
    else{
        this.showPanel(true);
    }
    var _this = this;
    function __mousemove(ev){_this.onmousemove(ev || _this._window.event);}
    function __mouseup(ev){_this.onmouseup(ev || _this._window.event);}
    im_wdkUtil.Event.addEvent(this._body, "mousemove", __mousemove);
    im_wdkUtil.Event.addEvent(this._body, "mouseup", __mouseup);
};
_p.startResize = function(ev, win, type){
    this.resizeWin = win;
    this.dir = type;
    
    if(im_global.cfg.customparams["entrytype"]=="toolbar" && type.indexOf("w") == -1){
        this.resizeX = win._self.offsetLeft;
        this.resizeY = win._self.offsetTop;
    }else{
        this.resizeX = ev.clientX - win._self.offsetLeft;
        this.resizeY = ev.clientY - win._self.offsetTop;
    }
    window.resizeSx = ev.clientX;
    window.resizeSy = ev.clientY;
    this.isresize = 1;
    if(im_wdkUtil.Browser.msie)
        win._self.setCapture();
    else
        this.showPanel(true);
};
_p.__timerRepos = function(){
    for(var i = 0; i < this._windows.length; i++){
        if(typeof(this._windows[i].refreshFlashPos)!="undefined"){
            this._windows[i].refreshFlashPos();
        }
    }
    if(this._windows.length>0)
        setTimeout("wdkApplication._FloatWindowManager.__timerRepos()",1000);
}
_p.dispose = function(){
    this.clientArea = null;
    for(var i = 0; i < this._windows.length; i++){
        this._windows[i].dispose();
        delete this._windows[i];
    }
};
_p.getPanel = function(){
    if(!this._panel){
        var _parm = {name:"div",style:"position:absolute;z-index:2;background:#EEEEEE;"};
        var obj = im_wdkUtil.createDom(_parm);
        if(im_wdkUtil.Browser.msie)
            obj.style.filter = "Alpha(Opacity=" + (wdkApplication._debug ? 50 : 0) + ")";
        else if(im_wdkUtil.Browser.mozilla)
            obj.style.MozOpacity = wdkApplication._debug ? 0.5 : 0;
        else
            obj.style.Opacity = wdkApplication._debug ? 0.5 : 0;
        var rect = im_wdkUtil.viewRect.get(window, true);
        obj.style.width = rect.w + "px";
        obj.style.height = rect.h + "px";
        //this._panel = this._doc.body.appendChild(obj);
        this._panel = obj;
        
    }
    return this._panel;
};
_p.showPanel = function(bShow){
    if(!this._panel)
        this.getPanel();
    var rect = im_wdkUtil.viewRect.get(window, true);
    this._panel.style.display = bShow ? "block" : "none";
    this._panel.style.left = rect.x + "px";
    this._panel.style.top = rect.y + "px";
    this._panel.style.width = (rect.w-20>0?(rect.w-20):0) + "px";
    this._panel.style.height = (rect.h-20>0?(rect.h-20):0) + "px";
};
_p.onmouseup = function(ev){
    this.showPanel(false);
    if(this.dragWin != null){
        if(im_wdkUtil.Browser.msie)
            this.dragWin._self.releaseCapture();
        this.dragWin = null;
        this.isDrag = 0;
    }
    if(this.resizeWin != null){
        if(im_wdkUtil.Browser.msie)
            this.resizeWin._self.releaseCapture();
        this.resizeWin = null;
        this.dir = "";
        this.isresize = 0;
    }
    if(this.isCascadeMode)
      this.isCascadeMode = false;
};
_p.onmousemove = function(ev){
    if(this.dragWin != null){
        var rect = im_wdkUtil.viewRect.get(window, true);
        var _entrytype = im_global.cfg.customparams["entrytype"];
        var x = this.dragSx + ev.clientX;
        var y = this.dragSy + ev.clientY;
        if(im_wdkUtil.Browser.msie || im_wdkUtil.Browser.opera){
            var max_height = Math.max(this._doc.documentElement.scrollHeight,this._doc.body.scrollHeight)<this._doc.documentElement.clientHeight ? this._doc.documentElement.clientHeight : Math.max(this._doc.documentElement.scrollHeight,this._doc.body.scrollHeight);
        }else{
            var max_height = Math.max(this._doc.documentElement.scrollHeight ,this._doc.body.scrollHeight )
        }
        
        if(this.isCascadeMode){
            x = this.dragSx-ev.clientX;
            y = this.dragSy-ev.clientY;
            im_chat_window_manager.dragMove(x, y);
        }
        else if(_entrytype=="toolbar"){
            //var _r    = im_wdkUtil.Browser.msie ? 1 : (im_wdkUtil.doc.scrollHeight>im_wdkUtil.doc.clientHeight ? 18 : 1);
            var _scroll = im_wdkUtil.scroll();
            var _r      = im_wdkUtil.Browser.msie ? 1 : (_scroll ? 18 : 1);
            
            if(!im_wdkUtil.Browser.oldModel){
                var _absX = x + this.dragWin._baseLeft;
                if(_absX+this.dragWin._self.offsetWidth+_r > rect.x+rect.w){
                    x = rect.x+rect.w - this.dragWin._baseLeft - this.dragWin._self.offsetWidth - _r;
                }else if(_absX > rect.x){
                    x = x;
                }else{
                    x = 0-this.dragWin._baseLeft;
                }
            }else{
                x = Math.max(Math.min(x, this._body.scrollLeft + this._doc.documentElement.offsetWidth - this.dragWin._self.offsetWidth), this._body.scrollLeft);
                x = (x+this.dragWin._self.offsetWidth)>this._body.clientWidth ? (this._body.clientWidth-this.dragWin._self.offsetWidth) : x;
            }
            
            y = (y+this.dragWin._self.offsetHeight)>max_height ? (max_height-this.dragWin._self.offsetHeight) : y;
            this.dragWin.moveTo(x, y);
        }
        else{
            x = Math.max(Math.min(x, this._body.scrollLeft + this._doc.documentElement.offsetWidth - this.dragWin._self.offsetWidth), this._body.scrollLeft);
            x = (x+this.dragWin._self.offsetWidth)>this._body.clientWidth ? (this._body.clientWidth-this.dragWin._self.offsetWidth) : x;
            y = (y+this.dragWin._self.offsetHeight)>max_height ? (max_height-this.dragWin._self.offsetHeight) : y;
            this.dragWin.moveTo(x, y);
        }
    }
    if(this.resizeWin != null){
        window.obj = {
            x: this.resizeWin._self.offsetLeft,
            y: this.resizeWin._self.offsetTop,
            w: this.resizeWin._self.offsetWidth,
            h: this.resizeWin._self.offsetHeight
        };
        this.resizing(ev, this.resizeWin);
        /*this.resizeWin.startResize(ev);*/
    }
};
_p.resizing = function(ev, win){
    var minWidth  = win._minWidth;
    var minHeight = win._minHeight;
    var flag = this.dir;
    var obj = window.obj;
    var x = obj.x;
    var y = obj.y;
    var w = obj.w;
    var h = obj.h;
    var entrytype = im_global.cfg.customparams["entrytype"]=="toolbar" && flag.indexOf("w") == -1;
    var _parentRect = im_wdkUtil.viewRect.get(this.resizeWin._self.parentNode);
    var ev_clientX = ev.clientX - (entrytype ? _parentRect.x : 0);
    var ev_clientY = ev.clientY - (entrytype ? _parentRect.y : 0);
    
    if(flag.indexOf("w") != -1){  /*左方*/
        w = obj.x + obj.w - ev_clientX + this.resizeX;
        if(w < minWidth) w = minWidth;
        x = obj.x + obj.w - w;
    }
    if(flag.indexOf("e") != -1){  /*右方*/
        w = ev_clientX - obj.x;
        if(w < minWidth) w = minWidth;
    }
    if(flag.indexOf("s") != -1){  /*下方*/
        h = ev_clientY - obj.y;
        if(h < minHeight) h = minHeight;
    }
    if(flag.indexOf("n") != -1){  /*上方*/
        h = obj.y + obj.h - ev_clientY + this.resizeY;
        if(h < minHeight) h = minHeight;
        y = obj.y + obj.h - h;
    }
    win.moveTo(x, y);
    win.resize(w, h);

    if(im_wdkUtil.Browser.msie)
        win._self.setCapture();
    ev.cancelBubble = true;  /*取消冒泡*/
    return false;
};
_p.updateWindowPos = function(winID, times){
    if(typeof(this._windows[winID].refreshFlashPos)!="undefined"){
        this._windows[winID].refreshFlashPos();
        if(times<2)
            window.setTimeout("wdkApplication._FloatWindowManager.updateWindowPos("+winID+", "+(times+1)+")", 1000);
        else
            im_global.temp.resetwintop[winID] = null;
    }
};

/**
 * class WDK_IM_PACK.IMWindow
 */
WDK_IM_PACK.IMWindow = function(){
    WDK_IM_PACK.FloatWindow.prototype.constructor();
    
    this._window = window;
    this._doc = this._window.document;
    this._self = null;

    this.bxMini0;
    this.minImg = null;
    this.minDiv = null;
    this.isLoad;
    this.maxwidth    = 135;
    this.maxheight   = 226;
    this.titleHeight = 20;  /*标题栏的高度*/
    this.borderWidth = 2;   /*边框宽度*/
    this._minWidth   = im_global.cfg.IMWidth;
    this._minHeight  = im_global.cfg.IMHeight;

    this._width      = im_global.cfg.IMWidth;
    this._height     = im_global.cfg.IMHeight;

    this.m_align;
    this.m_rlLong;
    this.m_miniImgBottom;
    this.m_tataType;
    this.m_wid;
    this.m_isButtonFloat = "float";
    this.m_miniIMgSrc;
    this.m_startShow;
    this.m_miniImgEvent;
    this.m_miniImgID;
    this.m_jsSrc;
    this.m_nick;
    this.m_title;
    this.m_enableEditNick;
    this._flashID;
    this.m_flashContainerID;
    this.m_miniImgDivID = "wdk_mini_state";
    this._titleid = "wdk_buddylist_title";


    this.timerID;
    this.isLocked = false;
    this.dockPos = "";  /*none|left|top|right|bottom*/
    this._leftright = 0;
    this._isPopup = false;
    this._popupWindow = null;

    this._flash;
    this.isInited = false;
    this.imEntrySpan = null;
    this.isMiniFloat = true;
    
    this.isShow = false;/*是否显示*/
    this._baseLeft = 0;
    this._baseTop  = 0;
};
WDK_IM_PACK.IMWindow.prototype = new WDK_IM_PACK.FloatWindow();
_p = WDK_IM_PACK.IMWindow.prototype;
_p.init = function(obj){
    if(this.isInited) return;
    this.isInited = true;

    this._flashID        = "wdk_buddylist_flash";  /*flash id*/
    this.m_miniImgBottom = this.m_miniImgBottom || "20";
    this._width = this._width || 180;
    this._height = this._height || 450;
    this.m_align = im_global.cfg.customparams["floatpos"] || "right";
    this.m_rlLong = this.m_rlLong || "20";
    this.m_isButtonFloat  = this.m_isButtonFloat || "float";
    this.m_miniImgEvent = this.m_miniImgEvent || "mouseup";

    this.m_jsURLPath = im_global.variable.scriptPath;
    this.isInPage = im_global.cfg.customparams["webchat_inpage"];

    var _this = this;
    
    _this.startWork();
};
_p.moveTo = function(x, y){
    var rect = im_wdkUtil.viewRect.get(window, true);
    this._left = x - rect.x;
    this._top = y - rect.y;
    this._right =  rect.x+rect.w-x;
    this._bottom = rect.y+rect.h-y;
    
    if(im_wdkUtil.Browser.msie){
        this._self.style.pixelLeft = x;
        this._self.style.pixelTop  = y;
    }else{
        this._self.style.left = x + "px";
        this._self.style.top  = y + "px";
    }
};
_p.resize = function(w, h){
    this._self.style.width  = w + "px";
    this._self.style.height = h + "px";
    var ch = h - 20 - this.borderWidth;
    this._self.childNodes[8].style.width = w + "px";
    this._self.childNodes[3].style.height = ch + "px";
    this._self.childNodes[4].style.height = ch + "px";
    if(this._flash){
        var fw = Math.max(w - 2 * this.borderWidth, 0);
        var fh = Math.max(h - 2 * this.borderWidth - this.titleHeight, 0);
        this._flash.setAttribute("width", fw);
        this._flash.setAttribute("height", fh);
        this._flash.style.width  = fw + "px";
        this._flash.style.height = fh + "px";
        this._flash.style.left = this.borderWidth + "px";
    }
};
_p.fooRepos = function(ev){
    var _entrytype = im_global.cfg.customparams["entrytype"];
    var rect = im_wdkUtil.viewRect.get(window, true);
    
    if(!im_wdkUtil.Browser.oldModel && _entrytype=="toolbar"){
        return;
    }
    if(ev&&ev.type == "resize"){
        if(!this._self) return;
        
        if(_entrytype=='toolbar'){
            var left = rect.w-this._width;
            var top  = rect.h-this._height - 25;
            this._left = left;
            this._top  = top;
            left = left + rect.x;
            top  = top + rect.y;
        }else{
            var left = Math.min(rect.x+this._left, (rect.x+rect.w-this._width-this.m_rlLong) );
            var top  = Math.min(rect.y+this._top, (rect.y+rect.h-this._height) );
        }

        if(im_wdkUtil.Browser.msie){
            this._self.style.pixelLeft = left;
            this._self.style.pixelTop = top;
        }else{
            this._self.style.left = left + "px";
            this._self.style.top  = top + "px";
        }

        if(this._self.offsetTop + this._self.offsetHeight - this._doc.body.scrollTop >= this._doc.documentElement.offsetHeight){
            wdkApplication._FloatWindowManager.isDrag = null;
        }
    }else{
        if(this.minDiv != null && this.m_isButtonFloat == "float"){
            this.minDiv.style.bottom = "";
            if(im_wdkUtil.Browser.msie){
                this.minDiv.style.top = (rect.y + rect.h - this.minDiv.scrollHeight - this.minDiv.y0) + "px";
            }else{
                this.minDiv.style.top = (rect.y + rect.h - this.minDiv.offsetHeight - this.minDiv.y0) + "px";
            }
        }
        if(this._self){
            var top = rect.y + this._top;
            if(im_wdkUtil.Browser.msie || im_wdkUtil.Browser.opera){
                var max_height  = Math.max(this._doc.documentElement.scrollHeight,this._doc.body.scrollHeight)<this._doc.documentElement.clientHeight ? this._doc.documentElement.clientHeight : Math.max(this._doc.documentElement.scrollHeight,this._doc.body.scrollHeight);
            }else{
                var max_height = Math.max(this._doc.documentElement.scrollHeight,this._doc.body.scrollHeight);
            }
            top = (top + this._height)>max_height  ? (max_height-this._height) : top;
            this._self.style.top  = top + "px";
        }
    }
};
_p.refreshFlashPos = function(){
  if(!this._flash  || this._curWindMode=="min")
    return;

  var moveOffset = 0;
  if(this._isMoveLeft){
    moveOffset = 1;
    this._isMoveLeft = false;
  }
  else{
    moveOffset = 0;
    this._isMoveLeft = true;
  }
  this._flash.style.left = (document.compatMode=='CSS1Compat' ? moveOffset : (this.borderWidth + moveOffset) )+"px";
}
_p.startWork = function(){
    if(this.isLoad == 1 || im_global.cfg.customparams["enblebuddyentry"]==0) return; /*入口关闭*/
    this.isLoad = 1;
    this.bxMini0 = this._doc.getElementById(this.m_miniImgDivID);
    var _this = this;

    if( this.m_bxMini0 == null){
        this.imEntrySpan = this._doc.getElementById("wdk_im_"+im_global.variable.user_id);
        if(im_global.variable.siteid=="cnmyspace" || im_global.variable.siteid=="xiaonengtest")
            var minDivStr = "<a id=\"wdk_mini_state_img\" style=\"\">在线聊天</a>";
        else{
            var minDivStr = "<img id=\"wdk_mini_state_img\" src=\""+im_global.cache.img["logo_mini"].src+"\"";
            if(this.imEntrySpan)
            	  minDivStr += " width='20px' height='20px' ";
            else
            	  minDivStr += " width='30px' height='30px' ";
            if(im_global.cfg.customparams["show_tooltip"])
                minDivStr += " tip=\"与我的好友聊天\" onload=\"im_showTip('wdk_mini_state_img')\"";
            minDivStr += " hspace=\"3\"\/>";
        }
        if(this.imEntrySpan && (im_global.cfg.customparams["entrytype"]=='logo' || im_global.cfg.customparams["enblebuddyentry"]==2) ){ //固定Mini
            this.imEntrySpan.innerHTML    = minDivStr;
            this.imEntrySpan.style.cursor = "pointer";
            //this.imEntrySpan.style.width = "20px";
            //this.imEntrySpan.style.height = "20px";
            this.imEntrySpan["on" + (this.m_miniImgEvent || "mouseup")] = function(){_this.showWindow(_this.isInPage);};
            this.isMiniFloat = false;
        }
        else if(im_global.cfg.customparams["entrytype"]=='logo'){
            this.minDiv = document.getElementById(this.m_miniImgDivID);
            if(!this.minDiv)
                  return;
            this.minDiv.innerHTML = minDivStr;
            this.minDiv.style.cssText = "position:absolute;visibility:hidden;z-index:999;cursor:pointer;"
              + this.m_align + ":" + this.m_rlLong + "px;";
            this.minDiv.y0 = this.m_miniImgBottom;
            this.minDiv.style.visibility = this.m_startShow == "win" ? "hidden":"visible";
            this.minDiv.style.display = this.m_startShow == "win" ? "none":"block";
            this.minDiv["on" + (this.m_miniImgEvent || "mouseup")] = function(){_this.showWindow(_this.isInPage);};
            this.fooRepos();
            this.isMiniFloat = true;
            wdkApplication._FloatWindowManager.addWindow(this);  /*注册该窗体*/
        }
        else{/*toolbar*/
            this.fooRepos();
            this.isMiniFloat = true;
            wdkApplication._FloatWindowManager.addWindow(this);  /*注册该窗体*/
        }
    }else{
        this.m_bxMini0["on" + (this.m_miniImgEvent || "mouseup")] = function(){_this.showWindow(_this.isInPage);};
    }
};
_p.createWin = function(){
    var resizebottomheight = Number(this._height);
    var rect = im_wdkUtil.viewRect.get(window, true);
    var _entrytype = im_global.cfg.customparams['entrytype'];
    var _scroll = im_wdkUtil.scroll();
    var _r    = im_wdkUtil.Browser.msie ? 1 : (_scroll ? 18 : 1);
    
    if( !im_wdkUtil.Browser.oldModel && _entrytype=="toolbar" ){
        var _TabRect   = im_wdkUtil.viewRect.get("im_buddylist_tab");
        this._baseLeft = _TabRect.x;
        this._baseTop  = _TabRect.y;
        this._self = im_wdkUtil.createDom({name:"DIV"}, im_wdkUtil.$("im_buddylist_tab"));
        this._self.style.position = "absolute";
        
        if(this.m_align=="left"){
            this._right = this._baseLeft;
            this._bottom = 0;
            this._left   = 0 - this._baseLeft;
            this._top    = 0;
        }else{
            if(this._baseLeft+this._width+_r > rect.x+rect.w){
                this._left  = rect.x + rect.w - this._width - this._baseLeft - _r;
                this._right = 0 - this._left;
            }
            this._top    = -1;
            this._bottom = 1;
        }
        this._self.style.left  = this._left + "px";
        this._self.style.bottom = this._bottom + "px";
    }else{
        this._self = im_wdkUtil.createDom({name:"DIV"});
        this._self.style.position = "absolute";
        //toolbar && ie56 && html 4.0 不留边距
        if(this.m_align=="left"){
            this._left   = rect.x + (_entrytype=="toolbar" ? 0 : this.m_rlLong);
            this._right  = rect.x + rect.w  - this._left - this._width - (_entrytype=="toolbar" ? _r : this.m_rlLong);
        }else{
            this._left   = rect.x + rect.w - this._width  - (_entrytype=="toolbar" ? _r : this.m_rlLong);
            this._right  = rect.x - (_entrytype=="toolbar" ? _r : this.m_rlLong);
        }
        
        this._top    = Math.max(rect.y, rect.y + rect.h - this._height - 25);
        this._bottom = 25;
        this._self.style.left   = this._left + "px";
        this._self.style.bottom = this._bottom + "px";
    }
    if(im_wdkUtil.$("im_buddylist_tab")) im_wdkUtil.$("im_buddylist_tab").style.display="block";
    
    this._self._ptr = this;   
    this._self.style.zIndex = im_wdkUtil.Browser.opera ? 1001 : (im_wdkUtil.Browser.msie ? 0 : 999);

    this.m_flashContainerID = "container_" + this._flashID;

    var bg = wdkApplication._debug ? "background-color:#000333;" : "background-image:url(" + im_global.cache.source + "blank.gif);";
    var ww = this.borderWidth;
    var ch = this._height - 20 - this.borderWidth;
    var sb = [];
    sb.push("<div type='nw' style='position:absolute;z-index:2;top:0px;left:0px;height:13px;width:13px;font-size:0;cursor:nw-resize;background-repeat:no-repeat;" + bg + "'></div>");      sb.push("<div type='n' style='position:absolute;z-index:1;top:0px;right:0px;height:" + ww + "px;width:100%;font-size:0;cursor:n-resize;background-repeat:repeat-x;" + bg + "'></div>");
    sb.push("<div type='ne'style='position:absolute;z-index:2;top:0px;right:0px;height:13px;width:13px;font-size:0;cursor:ne-resize;background-repeat:no-repeat;" + bg + "'></div>");
    
    sb.push("<div type='e' style='position:absolute;z-index:1;top:20px;right:0px;height:"+ch+"px;width:" + ww + "px;cursor:w-resize;background:url(" + im_global.cache.source + "win_con_rbg.gif) repeat-y'></div>");
    sb.push("<div type='w' style='position:absolute;z-index:1;left:0px;top:20px;height:"+ch+"px;width:" + ww + "px;cursor:w-resize;background:url(" + im_global.cache.source + "win_con_lbg.gif) repeat-y'></div>");
    sb.push("<div type='sw' style='position:absolute;z-index:2;bottom:0px;left:0px;height:13px;width:13px;font-size:0;/*cursor:sw-resize;*/background-repeat:no-repeat;" + bg + "'></div>");
    sb.push("<div type='s' style='position:absolute;z-index:1;bottom:0px;right:0;height:" + ww + "px;width:100%;font-size:0;cursor:s-resize;background:url(" + im_global.cache.source + "win_con_bbg.gif) repeat-x'></div>");
    sb.push("<div type='se' style='position:absolute;z-index:2;bottom:0px;right:0px;height:13px;width:13px;font-size:0;cursor:se-resize;background-repeat:no-repeat;" + bg + "'></div>");
    
    sb.push("<div type='dlgHead' style='cursor:move;position:absolute;left:0px;top:" + ww + "px;width:" + this._width + "px;height:" + this.titleHeight + "px;z-index:8;'>");
    sb.push("  <div type='dlgHead' style='position:absolute;left:0px;width:9px;top:0px;height:20px;z-index:4;background-image:url(" + im_global.cache.source + "win_tit_lbg.gif);'></div>");
    sb.push("  <div type='dlgHead' style='position:absolute;left:6px;width:96%;top:0px;height:20px;z-index:3;background:url(" + im_global.cache.source + "win_tit_bg.gif) repeat-x;'><div style='-moz-user-select: none;-khtml-user-select: none;user-select: none;font-size:"+im_global.win.fontsize+";color:"+im_global.win.fontcolor+";background:url("+im_global.cache.img["im_logo"].src+") no-repeat 4px 3px;height:20px;padding:"+(im_wdkUtil.Browser.oldModel ? 4 : 0)+"px 0px 0px "+(im_global.cache.img["im_logo"].width + 10)+"px;text-align:left;overflow:hidden'>"+im_global.win.fonttext+"</div></div>");
    sb.push("  <div type='dlgHead' style='position:absolute;right:0px;width:60px;top:0px;height:20px;z-index:5;background-image:url(" + im_global.cache.source + "win_tit_rbg.gif);'></div>");

    sb.push("</div>");
    /*sb.push("<div name='btmin'    type='button' style='position:absolute;z-index:9;right:25px;top:5px;font-size:0;width:11px;height:10px;background:url(" + im_global.cache.source + "im_btmin.gif)'></div>");*/
    sb.push("<div name='btpopup'  type='button' style='position:absolute;z-index:11;right:18px;top:4px;font-size:0;width:14px;height:14px;background:url(" + im_global.cache.source + "im_btpopup.gif)'></div>");
    sb.push("<div name='btclose'  type='button' style='position:absolute;z-index:11;right:7px;top:4px;font-size:0;width:14px;height:14px;background:url(" + im_global.cache.source + "im_btclose.gif)'></div>");
    sb.push("<div id='" + this.m_flashContainerID + "'><div id='" + this._flashID + "'><p style='padding-top:20px;text-align:center;color:"+im_global.win.fontcolor+";font-size:"+im_global.win.fontsize+";'><a href='http://www.adobe.com/go/getflashplayer' target='_blank'><img src='http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif' border='0' alt='Get Adobe Flash player' /><br />您未安装Flash插件,现在安装.</a></p></div></div>");
    if(im_wdkUtil.Browser.msie)
        sb.push('<iframe style="position:absolute;z-index:-1;width:100%;height:100%;top:0;left:0;scrolling:no;" frameborder="0" src="/about:blank"></iframe>');
    this._self.innerHTML = sb.join("");
    delete sb;
    if(im_wdkUtil.Browser.msie) CollectGarbage();
    this._self.style.display = "block";
    this._minBtn = this._self.childNodes[9];

    this._self.y0 = this._doc.body.clientHeight - this._self.offsetHeight;
    this._height0 = 14;
    var _this = this;

    var swfSrc = this.m_jsURLPath+"/imwdkbuddylist.swf"+"?version="+im_global.version.buddylist_flash+"&siteid="+encodeURIComponent(im_global.variable.siteid)+
      "&myuid="+encodeURIComponent(im_global.variable.user_id)+"&myname="+encodeURIComponent(im_global.variable.user_name)+"&sessionid="+encodeURIComponent(im_global.variable.user_sid)+
      "&from="+encodeURIComponent(window.location.host);
    if(im_global.variable.userparam)
    swfSrc += "&userparam="+encodeURIComponent(im_global.variable.userparam);
    var flashcontainer;
    flashcontainer = this._doc.getElementById(this.m_flashContainerID);
    
    if(flashcontainer){
        var flashmode = im_wdkUtil.Browser.msie ? "Opaque" : "Window";
        var params = {menu:"true", "salign":"LT", "allowScriptAccess":"always", "wmode":flashmode};
        var flashvars = false;
        /*var attributes = {id: "wdk_buddylist_flash", name: "wdk_buddylist_flash"};*/
        var attributes = {};
        var flashWidth = this._width - 2*this.borderWidth;
        swfobject.embedSWF(swfSrc, this._flashID, flashWidth, this._height, "9.0.0", im_global.variable.scriptPath+"/expressInstall.swf", flashvars, params, attributes);

        this._flash = document.getElementById(this._flashID);
        this._flash.style.background = '#ccc';
        this._flash.style.position = "absolute";
        this._flash.style.top = (this.borderWidth + this.titleHeight) + "px";
        this._flash.style.left = this.borderWidth + "px";
        this._flash.style.right = this.borderWidth + "px";
        this._flash.style.bottom = this.borderWidth + "px";
        this.resize(this._width, this._height);
        
        function __doEvent(e){_this.eventHandle(e || window.event);}
        this._self.onmouseover = __doEvent
        this._self.onmouseout  = __doEvent
        this._self.onmousedown = __doEvent
        this._self.onmouseup   = __doEvent;
    }

    if(!this.isMiniFloat){
        wdkApplication._FloatWindowManager.addWindow(this);  /*注册该窗体*/
    }
};
_p.eventHandle = function(ev){
    var event = ev||window.event;
    var ee = event.srcElement||event.target;
    if(ee.tagName == "IFRAME"){
        return;
        /*
        wdkApplication._FloatWindowManager.resizeWin = ee;
        wdkApplication._FloatWindowManager.dir = "";
        window.resizeSx = ev.clientX;
        window.resizeSy = ev.clientY;
        wdkApplication._FloatWindowManager.isresize = 1;
        if(im_wdkUtil.Browser.msie)
            ee.setCapture();
        return;
        */
    }
    if(ee.getAttribute("type") == "button"){
        switch(ev.type){
        case "mouseover":
            ee.style.backgroundPosition = "0 -" + ee.offsetHeight + "px";
            break;
        case "mouseout":
            ee.style.backgroundPosition = "0 0";
            break;
        case "mousedown":
            ee.style.backgroundPosition = "0 -" + (ee.offsetHeight * 2) + "px";
            break;
        case "mouseup":
            ee.style.backgroundPosition = "0 -" + ee.offsetHeight + "px";
            var eeName = ee.getAttribute("name");
            switch(eeName){
            case "btmin"   :
            case "btclose" :
              /*this.minimize();*/
              this.close(true);
              break;
            case "btpopup" :
              this.popup();
              break;
            }
        }
    }
    if(ee.getAttribute("type") == "dlgHead" || (typeof(ee.parentNode.getAttribute)!="undefined" && ee.parentNode.getAttribute("type")=="dlgHead")){
        switch(ev.type){
        case "mousedown":
            if(this.isLocked) return;
            wdkApplication._FloatWindowManager.startMove(ev, this);
            break;
        case "mouseup":
            wdkApplication._FloatWindowManager.showPanel(false);
            break;
        }
    }
    var type = ee.getAttribute("type");
    if(type == "nw" || type == "n" || type == "ne" || type == "s" || type == "se" || type == "w" || type == "e"){// || type == "sw"
        switch(ev.type){
        case "mousedown":
            wdkApplication._FloatWindowManager.startResize(ev, this, type);
            break;
        case "mouseup":
            wdkApplication._FloatWindowManager.showPanel(false);
            break;
            /*
        case "mouseover":
            if(type.indexOf("w") != -1)ee.style.borderLeft = "1px solid #999";
            if(type.indexOf("e") != -1)ee.style.borderRight = "1px solid #999";
            if(type.indexOf("s") != -1)ee.style.borderBottom = "1px solid #999";
            break;
        case "mouseout":
            if(type.indexOf("w") != -1)ee.style.borderLeft = "0px";
            if(type.indexOf("e") != -1)ee.style.borderRight = "0px";
            if(type.indexOf("s") != -1)ee.style.borderBottom = "0px";
            break;
            */
        }
    }
};
_p.updateMinButton = function(bMin){
    if(this._minBtn){
        this._minBtn.style.background = "url(" + im_global.cache.source + (bMin ? "im_btmin.gif" : "im_btbig.gif") + ")";
    }
};
_p.popup = function(){
  var popupWindow = im_openBuddyList(im_global.variable.user_id, im_global.variable.user_name, im_global.variable.user_sid, im_global.variable.siteid, im_global.variable.userparam, im_global.variable.scriptPath);
  if(popupWindow){
    this.close(false);
    this._isPopup = true;
    this._popupWindow = popupWindow;
  }
  else{
    alert("无法弹出窗口，请检查浏览器阻止弹出窗口设置或防火墙设置!");
  }
}
_p.popin = function(){
    this._isPopup = false;
    this._popupWindow = null;
    this.showWindow(this.isInPage);
    return true;
}
_p.closePopupWindow = function(){
  if(this._self)
    return;
  this._isPopup = false;
  this._popupWindow = null;
  if(this.minDiv)
      this.minDiv.style.visibility = "visible";
  return true;
}
_p.minimize = function(){
    if(this.minDiv)    this.minDiv.style.visibility = "visible";
    if(this._self)    this._self.style.visibility = "hidden";
    if(this._flash) this._flash.style.visibility = "hidden";
};
_p.close = function(isShowMini){
    if(!this._self)
        return;
    if(this._flash){
        if(this._flash.closeBuddylist)
            this._flash.closeBuddylist();
        /*清除DOM对象上面绑定的脚本对象*/
        im_wdkUtil.disposeFlashObj(this._flash);
        this._flash.parentNode.removeChild(this._flash);
    }

        this._self.onmouseover = null;
        this._self.onmouseout  = null;
        this._self.onmousedown = null;
        this._self.onmouseup   = null;
        this._self.onfocus   = null;
        this._self.onblur   = null;

    if(im_global.temp.buddylistFlashGoUrl){
        im_wdkUtil.createScript(im_global.temp.buddylistFlashGoUrl);
        im_global.temp.buddylistFlashGoUrl = null;
    }

    this._self.parentNode.removeChild(this._self);
    delete this._self;
    if(isShowMini && this.minDiv)
        this.minDiv.style.visibility = "visible";

    if(!this.isMiniFloat)
        wdkApplication._FloatWindowManager.removeWindow(this);
    if(im_wdkUtil.$("im_buddylist_tab"))
        im_wdkUtil.$("im_buddylist_tab").style.display = "none";
    this.isShow = false;
};
_p.showWindow = function(isInPage){
    if(this._popupWindow && this._popupWindow.document){
      this._popupWindow.focus();
    }
    else if(this._self == null){
        if(isInPage){
            this.createWin();
        }else{
            var popupWindow = im_openBuddyList(im_global.variable.user_id, im_global.variable.user_name, im_global.variable.user_sid, im_global.variable.siteid, im_global.variable.userparam, im_global.variable.scriptPath);
            if(!popupWindow){
                alert("无法弹出窗口，请检查浏览器阻止弹出窗口设置或防火墙设置!");
            }
            return;
        }
    }
    else{
       this._self.style.visibility = "visible";
       if(this._flash) this._flash.style.visibility = "visible";
    }
    
    if(im_installFlashActionX==true){
        var rect = im_wdkUtil.viewRect.get(window, true);
        if(offsetLeft && offsetTop){
            this.moveTo(parseInt(rect.x + offsetLeft), parseInt(rect.y + offsetTop) );
        }else{
            this.moveTo(parseInt( this._left + rect.x + this.m_rlLong ), this._top+rect.y);
        }
    }
    if(this.minDiv){
        this.minDiv.style.visibility = "hidden";
        var tipEl = im_wdkUtil.$('imiTwdk_mini_state_img');
        if( tipEl )
            tipEl.visibility = "hidden";
    }
    this.isShow = true;
    
};
_p.saveRect = function(){
    var rect = im_wdkUtil.viewRect.get(window, true);
    this._left = this._self.offsetLeft - rect.x;
    this._top = this._self.offsetTop - rect.y;
    this._width = this._self.offsetWidth;
    this._height = this._self.offsetHeight;
};
_p.OnTBShowBuddylist =function(x, y, show){
    var rect = im_wdkUtil.viewRect.get(window, true);
    offsetLeft = this.m_align=="left" ? x-rect.x : x-rect.x-this._width;
    offsetTop  = y - rect.y - this._height; 
    if(!show && this.isShow){
        this.close();
    }else if(show){
        this.showWindow(this.isInPage);
    }
}

WDK_IM_PACK.WDKChatWindow = function(destuid, destnick, chatid, layoutmode){
    WDK_IM_PACK.FloatWindow.prototype.constructor();
    this._destuid = destuid;
    this._destnick = destnick;
    this._window = window;
    this._layout = layoutmode; /*free|cascade|toolbar*/
    this._doc = this._window.document;
    this._self = null;
    this._selfid = "webchat_window"+destuid;
    this._titleid = "webchat_title"+destuid;
    this._headerid = "webchat_header"+destuid;

    this._width = im_global.cfg.chatWidth;
    this._height = im_global.cfg.chatHeight;
    this._avwidth = 340; /*视频区增加宽度*/
    this._avheight = 0;  /*视频区增加高度*/
    this._savewidth = null;
    this._saveheight = null;
    this._maxwidth = 135;
    this._maxheight = 226;
    this._titleHeight = 20;  /*标题栏的高度*/
    this._borderWidth = 2;  /*边框宽度*/
    this._minWidth  = 100;
    this._minHeight = 100;
    this._flashHeight = null;

    this._align = im_global.cfg.customparams["floatpos"] || "right";;
    this._rightOffset = 20;
    this._bottomOffset = 20;
    this._miniImgBottom;
    this._title;
    this._isFlashTitle = false;
    this._flashID = "webchat_flash"+destuid;
    this._flash = null;
    this._flashContainerID = "webchat_container"+destuid;
    this._flashcontainer;
    this._jsURLPath = im_global.variable.scriptPath;
    this._presenceFlashGoUrl = null;
    this._freeChatFlashGoUrl = null;
    this._defaultZIndex = 99;
    this._focusZIndex = 999;
    this._titlespan = null;
    this._headerdiv = null;
    this._curWindMode = "default"; /*"min" "max"*/
    this._flashTitleTimerID = null;
    /*this._isPopup = false;*/
    /*this._popupWindow = null;*/
    this._iframe = null;
    this._avStatus = "";
    this._top = 0;
    this._bottom = 0;
    this._left = 0;/*窗口左边距离客户区左边的距离*/
    this._right = 0;/*窗口右边距离客户区右边的距离*/
    this._chatid = chatid ? chatid:null;
    this.isInited = false;
    this._isFlashLoadSuccess = false;
    this._flashLoadTime = 30000; /*检测flash是否装载成功的时间，单位秒*/
    this._flashFailedDiv = null;
    this._checkFlashTimerid = null;
    
    this._entrytype = im_global.cfg.customparams["entrytype"];
    this._baseLeft = 0;
    this._baseTop  = 0;
};
WDK_IM_PACK.WDKChatWindow.prototype = new WDK_IM_PACK.FloatWindow();
_p = WDK_IM_PACK.WDKChatWindow.prototype;
_p.showWindow = function(offsetRight, offsetBottom, miniWinTabDOM){
    if(this.isInited) return;
    this.isInited = true;
    this._rightOffset = offsetRight ? offsetRight : 0;
    this._bottomOffset = offsetBottom ? offsetBottom : 0;
    var rect = im_wdkUtil.viewRect.get(window, true);
    if(miniWinTabDOM && !im_wdkUtil.Browser.oldModel && this._entrytype=="toolbar"){
        this._self = im_wdkUtil.createDom({name:"DIV"}, miniWinTabDOM);
        this._self.style.position = "relative";
        this._self.style.outlineStyle = "none";
        this._right  = offsetRight;
        this._bottom = offsetBottom;
        
        this._left   = 0-offsetRight;
        this._top    = 0-offsetBottom;
        
        var _tbX = im_wdkUtil.viewRect.get(miniWinTabDOM).x;
        var _selfaW = _tbX + this._width + im_global.cfg.IMWidth;
        if( _selfaW > rect.w ){
            var _scroll = im_wdkUtil.scroll();
            this._left = rect.w - im_global.cfg.IMWidth - this._width - _tbX - (_scroll ? 20 : 2);
        }
        
        this._self.style.left = this._left + "px";
        this._self.style.top = this._top + "px";
    }else{
        if(this._entrytype=="toolbar" && this._rightOffset<im_global.cfg.IMWidth){
            this._rightOffset = im_global.cfg.IMWidth + 2;
        }
        this._self = im_wdkUtil.createDom({name:"DIV"});
        this._self.style.position = "absolute";
        this._self.style.outlineStyle = "none";
        this._left = Math.max(0,rect.x + rect.w-this._width - this._rightOffset);
        this._right = this._rightOffset;
        
        this._bottom = this._bottomOffset;
        this._top = Math.max(0, rect.h - this._height - this._bottomOffset);
        this._self.style.left = this._left + "px";
        this._self.style.top = rect.y+this._top + "px";
        this._baseLeft = this._left;
        this._baseTop  = this._top;
    }
    
    this._self._ptr = this;   
    this._self.style.zIndex = 99;
    this._self.style.width = this._width+"px";
    this._self.style.height = this._height+"px";
    this._self.tabIndex = parseInt(this._destuid);

    var bg = "background-image:url(" + im_global.cache.source + "blank.gif);";
    this._titleText = "与 "+this._destnick+" 对话";
    var ww = this._borderWidth;
    var ch = this._height - this._titleHeight - this._borderWidth;
    this._iframeid = this._destuid+"_iframe";
    var sb = [];/*type n&s left:0px;*/
    sb.push("<div type='nw' style='position:absolute;top:0px;left:0px;height:13px;width:13px;font-size:0;cursor:nw-resize;background-repeat:no-repeat;" + bg + "'></div>");  
    sb.push("<div type='n' style='position:left:0px;absolute;top:0px;height:" + ww + "px;width:100%;font-size:0;cursor:n-resize;background-repeat:repeat-x;" + bg + "'></div>");
    sb.push("<div type='ne'style='position:absolute;top:0px;right:0px;height:13px;width:13px;font-size:0;cursor:ne-resize;background-repeat:no-repeat;" + bg + "'></div>");  
    
    sb.push("<div type='e' style='position:absolute;top:20px;right:0px;height:"+ch+"px;width:" + ww + "px;cursor:w-resize;background:url(" + im_global.cache.source + "win_con_rbg.gif) repeat-y'></div>");
    sb.push("<div type='w' style='position:absolute;top:20px;left:0px;height:"+ch+"px;width:" + ww + "px;cursor:w-resize;background:url(" + im_global.cache.source + "win_con_lbg.gif) repeat-y'></div>");
    sb.push("<div type='sw' style='position:absolute;bottom:0px;left:0px;height:13px;width:13px;font-size:0;cursor:sw-resize;background-repeat:no-repeat;" + bg + "'></div>");  
    sb.push("<div type='s' style='left:0px;position:absolute;bottom:0px;height:" + ww + "px;width:100%;font-size:0;cursor:s-resize;background:url(" + im_global.cache.source + "win_con_bbg.gif) repeat-x'></div>");
    sb.push("<div type='se' style='position:absolute;bottom:0px;right:0px;height:13px;width:13px;font-size:0;cursor:se-resize;background-repeat:no-repeat;" + bg + "'></div>");
    
    sb.push("<div type='dlgHead'  style='cursor:move;position:absolute;left:0px;top:" + ww + "px;width:100%;height:" + this._titleHeight + "px;'>");
    sb.push("  <div type='dlgHead' style='position:absolute;left:0px;width:9px;top:0px;height:100%;background-image:url(" + im_global.cache.source + "win_tit_lbg.gif);'></div>");
    /*sb.push("  <div type='dlgHead' style='position:absolute;left:0px;width:99%;top:0px;height:100%;text-align:center;background:url(" + im_global.cache.source + "win_tit_bg.gif) repeat-x;'><span style='padding-left:20px; font-size:12px; id='"+this._titleid+"'>"+this._titleText+"<span></div>");*/
    sb.push("<div type='dlgHead' style='position:absolute;left:9px;width:96%;top:0px;height:20px;background:url(" + im_global.cache.source + "win_tit_bg.gif) repeat-x;'><div id='"+this._titleid+"' style='-moz-user-select: none;-khtml-user-select: none;user-select: none;color:"+im_global.win.fontcolor+";font-size:"+im_global.win.fontsize+";background:url("+im_global.cache.img["im_logo"].src+") no-repeat 4px 3px;height:auto;text-align:left;padding-left:"+(im_global.cache.img["im_logo"].width+10)+"px;line-height:20px;'>"+this._titleText+"</div></div>");
    sb.push("  <div type='dlgHead' style='position:absolute;right:0px;width:60px;top:0px;height:100%;background-image:url(" + im_global.cache.source + "win_tit_rbg.gif);'></div>");

    sb.push("</div>");
    sb.push("<div name='btpopup'    type='button' style='position:absolute;right:43px;top:5px;font-size:0;width:14px;height:14px;background:url(" + im_global.cache.source + "im_btpopup.gif)'></div>");
    sb.push("<div name='btmin'    type='button'  style='position:absolute;right:25px;top:5px;font-size:0;width:14px;height:14px;background:url(" + im_global.cache.source + "im_btmin.gif)'></div>");
    sb.push("<div name='btclose'  type='button' style='position:absolute;right:7px;top:4px;font-size:0;width:14px;height:14px;background:url(" + im_global.cache.source + "im_btclose.gif)'></div>");
    sb.push("<div id='" + this._flashContainerID + "' style='position: absolute;'><div id='" + this._flashID + "'><p style='text-align:center;'><a href='http://www.adobe.com/go/getflashplayer' target='_blank'><img src='http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif' border='0' alt='Get Adobe Flash player' /><br />您未安装Flash插件,现在安装.</a></p></div></div>");
    /*sb.push("<iframe id='"+this._iframeid+"' width='100%' height='80%' style='position:absolute; top:30px; z-index:-1; border-style:none;'></iframe>");*/
    this._self.innerHTML = sb.join("");
    delete sb;
    this._minBtn = this._self.childNodes[10];
    this._titlespan = this._doc.getElementById(this._titleid).lastChild;
    this._headerdiv = this._doc.getElementById(this._headerid);
    /*this._iframe = this._doc.getElementById(this._iframeid);*/

    this._self.y0 = this._doc.body.clientHeight - this._self.offsetHeight;
    this._height0 = 14;
    this._flashcontainer = this._doc.getElementById(this._flashContainerID);
    this.createFlash();

    var _this = this;
    function __doEvent(e){_this.eventHandle(e || window.event);};
    this._self.onmouseover = __doEvent;
    this._self.onmouseout = __doEvent;
    this._self.onmousedown = __doEvent;
    this._self.onmouseup = __doEvent;
    this._self.onfocus = __doEvent;
    this._self.onblur = __doEvent;
    this._self.ondblclick = __doEvent;
    this.resize(this._width, this._height);
    wdkApplication._FloatWindowManager.addWindow(this); /*注册该窗体*/
};
_p.moveTo = function(x, y, isNotSavePos){
    var rect = im_wdkUtil.viewRect.get(window, true);
    if(typeof(isNotSavePos)=="undefined" || !isNotSavePos){
        if(this._entrytype=="toolbar" && !im_wdkUtil.Browser.oldModel){
            this._left = x;
            this._top  = y;
            this._right = 0-x;
            this._bottom = 0-y;
        }else{
            this._left   = x - rect.x;
            this._top    = y - rect.y;
            this._right  = rect.x + rect.w - x - this._width;
            this._bottom = rect.y + rect.h - y -this._height;
        }
    }
    if(im_wdkUtil.Browser.msie){
        this._self.style.pixelLeft = x;
        this._self.style.pixelTop  = y;
    }else{
        this._self.style.left = x + "px";
        this._self.style.top  = y + "px";
    }
};
_p.resize = function(w, h){
    this._width = w;
    this._height = h;
    this._self.style.width  = w + "px";
    this._self.style.height = h + "px";
    this._self.childNodes[8].style.width = w + "px";
    if(this._flash){
        this.setFlashStyle();
    }
};
_p.fooRepos = function(ev){
    var rect = im_wdkUtil.viewRect.get(window, true);
    if(this._entrytype=='toolbar' && !im_wdkUtil.Browser.oldModel)
        return;/*toolbar && ie && html4.0 滚动窗口或改变窗口大小时位置不发生变化 */
    
    if(ev && ev.type == "resize"){
        if(!this._self) return;
        
        var x = rect.x + rect.w-this._width-this._right;
        var y = rect.y + rect.h-this._height-this._bottom;
        if(this._entrytype=='toolbar'){
            if(this._curWindMode!='hide'){
                var _miniRect = im_toolbar.getMiniWinPos(this._destuid);
                var x = _miniRect.x;
                var y = _miniRect.y - this._height;
                if(this._align=="left"){
                    x = x+this._width>rect.x+rect.w ? rect.x+rect.w-this._width : x;
                    x = !im_wdkUtil.Browser.msie ? x-20 : x;
                }else{
                    x = x-this._width<rect.x ? rect.x : x-this._width;
                }
                //y = y>=rect.y ? y : rect.y;
            }else{
                x = -2000;
            }
        }else{
            x = x>=rect.x ? x : rect.x;
            y = y>=rect.y ? y : rect.y;
        }
        
        this.moveTo(x, y, true);//不更新位置
    }
    else if(this._self){
        var rect = im_wdkUtil.viewRect.get(window, true);
        var x = rect.x + this._left;
        var y = rect.y + this._top;
        if(this._entrytype=='toolbar'){
            y = y+this._height>rect.y+rect.h ? rect.y+rect.h-this._height-25 : y;
        }else{
            this._self.style.left = x + "px";
        }       
        this._self.style.top  = y + "px";
        
        if(this._flash){
            this._flash.style.left = (document.compatMode=='CSS1Compat' ? this._borderWidth : this._borderWidth )+"px";
        }
    }
};
_p.hide = function(){
    if(this._curWindMode=='default')
        this.minimize();
};
_p.show = function(offsetLeft, offsetTop){
    if(this._curWindMode=='hide'){
        this.minimize();
        if(offsetLeft && offsetTop){
            var _rect = im_wdkUtil.viewRect.get(window,true);
            this.moveTo(_rect.x + offsetLeft, _rect.y + (offsetTop-this._height) );
        }
    }
};
_p.minimize = function(){
    var visiblestyle;
    var displaystyle;
    switch(this._curWindMode){
    case "default":
        visiblestyle = "hidden";
        displaystyle = "none";
        this._curWindMode = "min";
        this._flashcontainer.style.width = "1px";
        this._flashcontainer.style.height = "1px";
        this._flash.style.width = "1px";
        this._flash.style.height = "1px";
        if(this._avStatus=="vedio" && this._savewidth){
            this._self.style.width = this._savewidth + "px";
            this._self.childNodes[8].style.width = Math.max(this._savewidth - 2 * this._borderWidth, 0) + "px";
        }
        this._self.style.height = this._titleHeight + "px";
        this._minBtn.style.background = "url(" + im_global.cache.source + "im_btbig.gif)";
        
        if( this._layout=="toolbar" ){
            this._curWindMode = "hide";
            this.moveTo(-2000, 0, true);
        }
        break;
    case "min":
        visiblestyle = "visible";
        displaystyle = "block";
        this._curWindMode = "default";
        this._self.style.width = this._width + "px";
        this._self.style.height = this._height+"px";
        this._flash.style.height = this._flashHeight;
        this._minBtn.style.background = "url(" + im_global.cache.source + "im_btmin.gif)";
        this.stopFlashTitle();
        this.resize(this._width, this._height);
        break;
    default:
        visiblestyle = "visible";
        this._curWindMode = "default";
        break;
    }
    for(var i=3;i<8;i++){
        this._self.childNodes[i].style.visibility = visiblestyle;
        this._self.childNodes[i].style.display = displaystyle;
    }
    /*this._flash.style.visibility = visiblestyle;*/
};
_p.MinMax = function(x, y){/*用于toolbar*/
    var visiblestyle;
    var displaystyle;
    switch(this._curWindMode){
    case "default":
        visiblestyle = "hidden";
        displaystyle = "none";
        this._curWindMode = "hide";
        this._flashcontainer.style.width = "1px";
        this._flashcontainer.style.height = "1px";
        this._flash.style.width = "1px";
        this._flash.style.height = "1px";
        if(this._avStatus=="vedio" && this._savewidth){
            this._self.style.width = this._savewidth + "px";
            this._self.childNodes[8].style.width = Math.max(this._savewidth - 2 * this._borderWidth, 0) + "px";
        }
        this._self.style.height = this._titleHeight + "px";
        this._minBtn.style.background = "url(" + im_global.cache.source + "im_btbig.gif)";
        im_toolbar.getMiniWindow(this._destuid).onBlur();/*最小化时修改当前miniWindow状态*/
        this.moveTo(-2000, 0, true);
        break;
    case "hide":
        visiblestyle = "visible";
        displaystyle = "block";
        this._curWindMode = "default";
        this._self.style.width = this._width + "px";
        this._self.style.height = this._height+"px";
        this._flash.style.height = this._flashHeight;
        this._minBtn.style.background = "url(" + im_global.cache.source + "im_btmin.gif)";
        this.stopFlashTitle();
        this.resize(this._width, this._height);
        
        var rect = im_wdkUtil.viewRect.get(window,true);
        im_toolbar.getMiniWindow(this._destuid).onFocus();
        if(x && y && im_wdkUtil.Browser.oldModel){
            x = !im_wdkUtil.Browser.msie ? x - 20 : x;
            if(this._align=="left")
                x = (x+this._width)>(rect.x+rect.w) ? rect.x+rect.w-this._width : x;
            else
                x = x-this._width<rect.x ? rect.x : x-this._width;
        }else if(this._left==0 && this._top==0 && x && y){
            x = 0;
            y = 0;
        }else{
            x = this._left;
            y = this._top;
        }
        this.moveTo(x, y);
        break;
    default:
        visiblestyle = "visible";
        this._curWindMode = "default";
        break;
    }
    for(var i=3;i<8;i++){
        this._self.childNodes[i].style.visibility = visiblestyle;
        this._self.childNodes[i].style.display = displaystyle;
    }
    this._flash.style.visibility = visiblestyle;
};
_p.close = function(){
    this.stopFlashTitle();
    this._flash = document.getElementById(this._flashID);
    if(this._checkFlashTimerid){
        clearTimeout(this._checkFlashTimerid);
    }
    if(this._flash){
        /*if(this._flash.closeWebchat){
            //此函数调用可能会出现异常，必须捕获异常，否则会导致聊窗无法关闭
            try{
                this._flash.closeWebchat();
            }catch(e){
            }
        }*/
        if(this._flash.closeBuddylist)
           this._flash.closeBuddylist();
        /*清除DOM对象上面绑定的脚本对象*/
        im_wdkUtil.disposeFlashObj(this._flash);
        this._flash.parentNode.removeChild(this._flash);
        delete this._flash;
    }
    this._self.onmouseover = null;
    this._self.onmouseout  = null;
    this._self.onmousedown = null;
    this._self.onmouseup   = null;
    this._self.onfocus   = null;
    this._self.onblur   = null;
    this._self.ondblclick = null;
        
    if(this._freeChatFlashGoUrl){
        im_wdkUtil.createScript(this._freeChatFlashGoUrl);
        /*alert("this._freeChatFlashGoUrl:"+this._freeChatFlashGoUrl);*/
    }

    if(this._presenceFlashGoUrl){
       im_wdkUtil.createScript(this._presenceFlashGoUrl);
       /*alert("this._presenceFlashGoUrl:"+this._presenceFlashGoUrl);*/
    }

    im_chat_window_manager.removeChatWindow(this._destuid);
    this._self.parentNode.removeChild(this._self);
    delete this._self;
    
    if(im_global.cfg.customparams["entrytype"]=='toolbar'){//
        im_toolbar.OnRemoveChatWindow(this._destuid);
    }
    wdkApplication._FloatWindowManager.removeWindow(this);
};
_p.startFlashTitle = function(titleText){
    if(this._flashTitleTimerID)
        return;
    this._flashTitleText = im_wdkUtil.cutText(titleText,20);
    /*_thisobj = this;*/
    /*this._flashTitleTimerID = setInterval("_thisobj.changeTitle()", 1000);*/
    this._flashTitleTimerID = setInterval("im_chat_window_manager.flashWindowTitle('"+this._destuid+"')",1000);
};
_p.changeTitle = function(titleText){
    this._titlespan.nodeValue =  titleText;
    this._isFlashTitle = this._isFlashTitle ? false:true;
};
_p.stopFlashTitle = function(titleTxt){
    if(this._flashTitleTimerID){
        clearInterval(this._flashTitleTimerID);
        this._flashTitleTimerID = null;
        this._titlespan.nodeValue = this._titleText;
        this._isFlashTitle = false;
    }
};
_p.createFlash = function(bRefresh){
    if(!this._flashcontainer)
    return;

    var swfname = "imbuddylist.swf";
    var swfSrc = this._jsURLPath+"/"+swfname+"?version="+im_global.version.webchat_flash+"&siteid="+encodeURIComponent(im_global.variable.siteid)+
        "&myuid="+encodeURIComponent(im_global.variable.user_id)+"&myname="+encodeURIComponent(im_global.variable.user_name)+"&destuid="+encodeURIComponent(this._destuid)+
        "&destname="+encodeURIComponent(this._destnick)+"&sessionid="+encodeURIComponent(im_global.variable.user_sid)+"&from="+encodeURIComponent(window.location.host);
    if(typeof(bRefresh)!="undefined" && bRefresh){
        swfSrc += "&rand="+Math.random();
    }
    if(im_global.variable.userparam)
        swfSrc += "&userparam="+encodeURIComponent(im_global.variable.userparam);
        if(this._chatid)
            swfSrc = swfSrc+"&chatid="+this._chatid;
        var flashmode = im_wdkUtil.Browser.msie?"Opaque":"Window";
        var flashmode = "Window";
        var params = {menu:"true", "salign":"LT", "allowScriptAccess":"always", "wmode":flashmode};
        var noflashvars = false;
        var attributes = false;
        var fw = Math.max(this._width - this._borderWidth, 0);
        var fh = this._height-this._titleHeight - this._borderWidth;
        swfobject.embedSWF(swfSrc, this._flashID, fw, fh,  "9.0.0", im_global.variable.scriptpath+"/expressInstall.swf", noflashvars, params, attributes);
        this._flash = document.getElementById(this._flashID);
        this.setFlashStyle();
        if(this._flash.tagName.toLowerCase()=="object"){
            var _this = this;
            var __checkFlashLoad =function(){ _this.checkFlashLoad();
        };
        //this._checkFlashTimerid = setTimeout(__checkFlashLoad, this._flashLoadTime);
    }
}
_p.setFlashStyle = function(){
    var fw = Math.max(this._width - this._borderWidth*(im_wdkUtil.Browser.mozilla || im_wdkUtil.Browser.firefox ? 2 : 1), 0);//?
    var fh = this._height-this._titleHeight - this._borderWidth;
    this._flashcontainer.style.top = this._titleHeight+"px";
    this._flashcontainer.style.left = "0px";
    this._flashcontainer.style.width = fw+"px";
    this._flashcontainer.style.height = fh+"px";
    this._flashcontainer.style.overflow = "hidden";

    this._flash.style.background = '#ccc';
    this._flash.style.position = "relative";
    this._flash.style.width  = fw + "px";
    this._flash.style.height = fh + "px";
    var browser = im_wdkUtil.Browser;
    this._flash.style.left = this._borderWidth + "px";
    //this._flash.style.bottom = this._borderWidth + "px";
    this._flashHeight = this._flash.style.height;
  }
_p.checkFlashLoad = function(){
  if(!this._isFlashLoadSuccess){
    var _this = this;
    this._restoreFlash = this._flash;
    /*this._flashcontainer.removeChild(this._restoreFlash);*/
    var __reloadFlash = function(){_this.reloadFlash();};
    var __restoreFlash = function(){_this.restoreFlash();};
    var reloadid= "chatreload"+this._destuid;
    var restorid= "chatrestore"+this._destuid;

    var _parm = {name:"div",style:"position:absolute;overflow:hidden;width:100%;"};
    this._flashFailedDiv = im_wdkUtil.createDom(_parm, this._flashcontainer);
    this._flash.style.width = "1px";
    this._flash.style.height = "1px";
    this._flash = this._flashFailedDiv;
        
    document.getElementById(reloadid).onclick = __reloadFlash;
    document.getElementById(restorid).onclick = __restoreFlash;
  }
}
_p.restoreFlash = function(){
    if(this._flashFailedDiv){
       this._flashcontainer.removeChild(this._flashFailedDiv);
       delete this._flashFailedDiv;
    }
    this._flash = this._restoreFlash;
    this.resize(this._width, this._height);
    this._flash.focus();
}
_p.reloadFlash = function(){
  if(this._restoreFlash){
       delete this._restoreFlash;
     }
     this._flash = null;
     if(this._flashFailedDiv){
       this._flashcontainer.removeChild(this._flashFailedDiv);
       delete this._flashFailedDiv;
     }
     this._flashcontainer.innerHTML = "<div id='" + this._flashID + "'></div>";
     this.createFlash(true);
}
_p.onFlashLoadSuccess = function(){
  //return;
  this._isFlashLoadSuccess = true;
}
_p.eventHandle = function(ev){
    var event = ev||window.event;
    var ee = event.srcElement||event.target;
    if(typeof(ee.getAttribute)=="undefined")
        return;
    if(ee.getAttribute("type") == "button"){
        switch(ev.type){
        case "mouseover":
            ee.style.backgroundPosition = "0 -" + ee.offsetHeight + "px";
            break;
        case "mouseout":
            ee.style.backgroundPosition = "0 0";
            break;
        case "mousedown":
            ee.style.backgroundPosition = "0 -" + (ee.offsetHeight * 2) + "px";
            break;
        case "mouseup":
            ee.style.backgroundPosition = "0 -" + ee.offsetHeight + "px";
            var eeName = ee.getAttribute("name");
            switch(eeName){
            case "btmin":
               if(this._layout=="cascade"){
                   if(this._curWindMode=="min")
                       this.onFocus();
                   else
                       im_chat_window_manager.minCurWindow();
               }
               else if( this._layout=="toolbar" ){/*toolbar*/
                   this.MinMax();
               }else{/*free*/
                   this.minimize();
               }
               break;
            case "btclose" :
               this.close();
               break;
            case "btpopup" :
               this.popup();
               break;
            };
        }
    }
    /*IE下div收不到focus事件，通过mousedown来处理focus*/
    if(ev.type=="mousedown" && ee.getAttribute("type")!="button")
        this.onFocus();

    if(ee.getAttribute("type") == "dlgHead" || (typeof(ee.parentNode.getAttribute)!="undefined" && ee.parentNode.getAttribute("type") == "dlgHead")){
        switch(ev.type){
            case "mousedown":
                if(this.isLocked) return;
                wdkApplication._FloatWindowManager.startMove(ev, this, this._layout=="cascade");
                break;
            case "mouseup":
                wdkApplication._FloatWindowManager.showPanel(false);
                break;
            case "focus":
                this.onFocus();
                break;
            case "blur":
                this.onBlur();
                break;
            case "dblclick":
                if(this._layout=="cascade"){
                    /*if(this._curWindMode=="min")
                        this.onFocus();
                    else
                        im_chat_window_manager.minCurWindow();*/
                }
                else
                    this.minimize(eeName);
                break;
        }
    }
    if(this._layout=="free"){
        var type = ee.getAttribute("type");
        if(type == "nw" || type == "n" || type == "ne" || type == "sw" || type == "s" || type == "se" || type == "w" || type == "e"){
            switch(ev.type){
                case "mousedown":
                    wdkApplication._FloatWindowManager.startResize(ev, this, type);
                    break;
                case "mouseup":
                    wdkApplication._FloatWindowManager.showPanel(false);
                    break;
            }
        }
    }
};
/*firefox下flash设置为window模式时有时无法刷新位置，定时调用本函数强制刷新*/
_p.refreshFlashPos = function(){
  if(!this._flash  || this._curWindMode=="min" || this._entrytype=="toolbar")
    return;

    var moveOffset = 0;
  if(this._isMoveLeft){
        moveOffset = 1;
    this._isMoveLeft = false;
  }
  else{
    moveOffset = 0;
    this._isMoveLeft = true;
  }
    this._flash.style.left = (document.compatMode=='CSS1Compat' ? moveOffset : (this._borderWidth + moveOffset) )+"px";
}
_p.onFocus = function(){
  this._self.style.zIndex = this._focusZIndex;
  this._flashcontainer.style.zIndex = this._focusZIndex;
  this._flash.style.zIndex = this._focusZIndex;
  /*this._iframe.style.zIndex = this._focusZIndex-1;*/
  /*in ie blue event cannot be fired, so use this mothod to unfocus other chat window*/
  im_chat_window_manager.focusWindow(this._destuid);
};
/*in ie blue event cannot be fired*/
_p.onBlur = function(){
  this._self.style.zIndex = this._defaultZIndex;
  this._flashcontainer.style.zIndex = this._defaultZIndex;
  this._flash.style.zIndex = this._defaultZIndex;
  /*this._iframe.style.zIndex = -1;*/
  this._flash.style.visibility = "hidden";
  this._flash.style.visibility = "visible";
};
_p.popup = function(){
  var prompStr = null;
  if(this._avStatus=="audio")
    prompStr = "您与对方正在进行语音会话，弹出聊窗将会中断音频会话，您确定吗？";
  else if(this._avStatus=="vedio")
    prompStr = "您与对方正在进行音视频会话，弹出聊窗将会中断音视频会话，您确定吗？";

  if(prompStr && !confirm(prompStr))
    return;

  var popupWindow = im_openWebchat(im_global.variable.user_id, im_global.variable.user_name, im_global.variable.user_sid, im_global.variable.siteid, this._destuid, this._destnick, this._chatid, im_global.variable.userparam, true, im_global.variable.scriptPath)
  if(popupWindow){
    /*this._isPopup = true;*/
    /*this._popupWindow = popupWindow;*/
    im_chat_window_manager.addPopupWindow(this._destuid, popupWindow);
    this.close(true);
  }
  else{
    alert("无法弹出窗口，请检查浏览器阻止弹出窗口设置或防火墙设置!");
  }
}
_p.openAV = function(isVedio){
    if(this._curWindMode=="min" && this._layout=="free")
        this.minimize();

    var calltype = "";
    if(isVedio && this._avStatus!="vedio"){
        this._avStatus = "vedio";
        this._savewidth = this._width;
        this._saveheight = this._height;
        this._width = this._savewidth+this._avwidth;
        this._height = this._saveheight+this._avheight;
        if(this._curWindMode=="default" || this._layout=="free")
            this.resize( this._width, this._height);
        calltype = "音视频会话";
    }
    else if(this._avStatus!="audio"){
        this._avStatus = "audio";
        calltype = "音频会话";
    }

    this._titleText = "与"+this._destnick+calltype;
    this.changeTitle(this._titleText);
    var promptTitle = this._destnick+"请求与你"+calltype;
    if(promptwindow)
        promptwindow.startPrompt(promptTitle, true);
    if(this._curWindMode=="min")
        this.startFlashTitle(promptTitle);
}
_p.closeAV = function(isVedio){
  if(this._avStatus == "vedio" && this._savewidth){
    this._width = this._savewidth;
    this._height = this._saveheight;
    if(this._curWindMode=="default" || this._layout=="free")
      this.resize(this._width, this._height);
  }
  this._avStatus = "";
  if(this._curWindMode=="min"){
    this.stopFlashTitle();
  }
  this._titleText = "与"+this._destnick+"对话";
  this.changeTitle(this._titleText);
}
_p.onReceiveMessage = function(message){
    if(this._curWindMode=="min" || this._curWindMode=="hide"){
        var titleText = this._destnick + unescape("说：")+message;
        this.startFlashTitle(titleText);
        if(this._entrytype=="toolbar"){
            if(im_global.cfg.DebugType==2) dzy_debug.debug("收到"+this._destnick+"的消息");
            var miniWindow = im_toolbar.getMiniWindow(this._destuid);
            miniWindow.onReceiveMiniMessage(message);
        }
    }
}
/*聊窗连接失败后，precence收到对方的消息，通知聊窗重新连接*/
_p.onPresenceReceiveChatMsg = function(message){
    if(this._flash && this._flash.presenceReceiveChatMsg)
        this._flash.presenceReceiveChatMsg(message);
};

WDK_IM_PACK.ChatWindowManager = function(){
    this._chatWnds = new IMHashtable();
    this._chatWndsArray = new Array();
    this._popupChatWnds = new IMHashtable();
    this._creatingFlashWnds = new Array();
    this._windowWidth  = im_global.cfg.chatWidth;
    this._windowHeight = im_global.cfg.chatHeight;
    this._windowTitleHeight = 20;
    this._layout = im_global.cfg.customparams["layout"]; /*free|cascade|toolbar*/
    var rect = im_wdkUtil.viewRect.get(window, true);
    this._align = im_global.cfg.customparams["floatpos"];
    //this._layoutRight = this._align=='right' ? (this._windowWidth+20) : rect.w-this._windowWidth*2;
    this._layoutRight = this._windowWidth+20;
    this._layoutBottom = 0;
    this._curLayoutTop = 0;
    this._curChatWindow = null;
    this._curWindowIndex = -1; /*当前正在打开的聊窗序号*/
}
_p = WDK_IM_PACK.ChatWindowManager.prototype;
/*在cascade模式下，isAutoFocus参数表示是否自动把新窗口作为当前窗口，并把其他窗口最小化*/
/*在toolbar模式下，......*/
_p.addChatWindow = function(destuid, destnick, chatid, isAutoFocus, message){
    var chatWindow = this.getChatWindow(destuid);
    if(chatWindow){
        chatWindow.onFocus();
        this.OnTBFocusWindow(destuid);
        chatWindow.onPresenceReceiveChatMsg(message);
        return;
    }
    chatWindow = this.getPopupWindow(destuid);
    if(chatWindow && chatWindow.document){
        chatWindow.focus();
        if(typeof(message)!="undefined" && message)
            chatWindow.onPresenceReceiveChatMsg(message);
        return;
    }

    var rect = im_wdkUtil.viewRect.get(window, true);
    var newChatWindow = new WDK_IM_PACK.WDKChatWindow(destuid, destnick, chatid, this._layout);
    if(this._layout=="free"){
        maxRowWindows = parseInt((rect.w-220)/newChatWindow._width);
        maxCollumWinows = parseInt((rect.h-20)/newChatWindow._height);
        curWinRows = parseInt(this._chatWnds.count()/maxRowWindows);
        curWinCollums = this._chatWnds.count()%(maxRowWindows==0 ? 1 : maxRowWindows);
        rightOffset = curWinCollums*newChatWindow._width+220;
        bottomOffset = curWinRows*newChatWindow._height+20;
        newChatWindow.showWindow(rightOffset, bottomOffset);
    }
    else if(this._layout=="cascade"){
        if(isAutoFocus && this._curWindowIndex>=0){/*如果要求自动打开新窗口，而且有当前窗口，则先最小化当前窗口*/
            this._curWindowIndex = -1;
            this.layoutWindow();
        }
        newChatWindow.showWindow(this._layoutRight, this._curLayoutTop);
        if(isAutoFocus || this._curWindowIndex==-1){/*如果要求自动打开新窗或者目前没有窗口是展开的，则新窗口是最大化形式*/
            this._curWindowIndex = this._chatWndsArray.length;
            curWindowHeight = newChatWindow._height;
        }
        else{
            newChatWindow.minimize();
            curWindowHeight = this._windowTitleHeight;
            leftPos = Math.max(0, rect.x + rect.w-this._windowWidth - this._layoutRight);
            topPos  = Math.max(0, rect.y + rect.h - this._curLayoutTop - curWindowHeight);
            newChatWindow.moveTo(leftPos, topPos);
            if(typeof(message)!="undefined" && message){
                var titleText = destnick+"说："+message;
                newChatWindow.startFlashTitle(titleText);
            }
        }
        this._curLayoutTop += curWindowHeight;
    }else if(this._layout=="toolbar"){/*toolbar*/
        for(var i=0; i<this._chatWndsArray.length; i++){//最小化并隐藏其它窗口
            this._chatWndsArray[i].hide();
        }
        var _floatpos = im_global.cfg.customparams['floatpos'];
        var _miniRect = im_toolbar.OnAddChatWindow(destuid, destnick, true);
        //var _r    = im_wdkUtil.Browser.oldModel && !im_wdkUtil.Browser.msie56 ?  1 : (im_wdkUtil.doc.scrollHeight>im_wdkUtil.doc.clientHeight ? 18 : 2);
        var _scroll = im_wdkUtil.scroll();
        var _r    = im_wdkUtil.Browser.msie ? 1 : (_scroll ? 18 : 1);
        
        if(im_wdkUtil.Browser.oldModel){//ie && html4.0
            if(_floatpos=="left"){
                rightOffset = rect.x + rect.w - _miniRect.x - this._windowWidth;
            }else{
                rightOffset = rect.x + rect.w - _miniRect.x;
            }
            rightOffset = rightOffset<_r ? _r :rightOffset;
            bottomOffset = rect.y + rect.h - _miniRect.y;
            newChatWindow.showWindow(rightOffset, bottomOffset);
        }else{
            newChatWindow._baseLeft = (_floatpos=="left" ? _miniRect.x : _miniRect.x-this._windowWidth);
            newChatWindow._baseTop  = _miniRect.y;
            
            var miniWinDOM_Tab = _miniRect.o.getElementsByTagName("DIV")[0];
            miniWinDOM_Tab.style.left = newChatWindow._baseLeft + "px";
            miniWinDOM_Tab.style.top  = (0-this._windowHeight) + "px"; //ie6 
            
            var _TabRect = im_wdkUtil.viewRect.get(miniWinDOM_Tab);
            var _abcX = newChatWindow._baseLeft + 0;
            var _width = newChatWindow._width;
            
            
            if( _abcX+_width+_r > rect.x+rect.w ){
                rightOffset  = 0 - (rect.x+rect.w - _width - _abcX - _r);
            }else if(_abcX < rect.x){
                rightOffset  = _abcX - rect.x;
            }else{
                rightOffset  = 0;
            }
            bottomOffset = 0;
            
            newChatWindow.showWindow(rightOffset, bottomOffset, miniWinDOM_Tab);
        }
    }

    this._chatWnds.add(destuid, newChatWindow);
    this._chatWndsArray.push(newChatWindow);
    this._curChatWindow = newChatWindow;
}
_p.addPopupWindow = function(destuid, popupWindow){
    this._popupChatWnds.add(destuid, popupWindow);
}
_p.removeChatWindow = function(destuid){
    var chatWindow = this.getChatWindow(destuid);
    if(!chatWindow)
        return false;
    this._chatWnds.remove(destuid);
    var isCurWindow = false;
    var deleteWindowIndex = -1;
    for(i=0; i<this._chatWndsArray.length; i++){
        if(this._chatWndsArray[i]._destuid==destuid){
            this._chatWndsArray.splice(i,1);
            deleteWindowIndex = i;
            if(i==this._curWindowIndex)
                isCurWindow = true;
            break;
        }
    }
    if(this._chatWndsArray.length==0){
        this._curWindowIndex = -1;
        this._curLayoutTop = this._layoutBottom;
        return;
    }
    if(isCurWindow){
        if(this._curWindowIndex==0){
            newCurWindowIndex = this._curWindowIndex;
            this._curWindowIndex = -1;
        }
        if(this._curWindowIndex>0){
            newCurWindowIndex = this._curWindowIndex-1;
            this._curWindowIndex = -1;
        }
        this.layoutWindow(this._chatWndsArray[newCurWindowIndex]._destuid);
    }
    else{
        if(deleteWindowIndex < this._curWindowIndex)
            this._curWindowIndex--;
        this.layoutWindow();
    }
}
_p.removePopupWindow = function(destuid){
    this._popupChatWnds.remove(destuid);
}
_p.focusWindow = function(destuid){
    var chatWindow = this.getChatWindow(destuid);
    if(chatWindow._curWindMode == "default")
        return;

    if(this._layout=="cascade")
        this.layoutWindow(destuid);
    else{
        for(var k in this._chatWnds._hash){
            chatWindow = this._chatWnds._hash[k];
            if(chatWindow._destuid!=destuid){
                chatWindow.onBlur();
            }
        }
    }
}
_p.layoutWindow = function(newCurWindowUid){
  if(this._layout!="cascade")
    return;

  /*if(!newCurWindowUid)*/
  /*  newCurWindowUid = this._curWindowIndex;*/
  var rect = im_wdkUtil.viewRect.get(window, true);
  this._curLayoutTop = this._layoutBottom;
  var newCurWindowIndex = -1;
  var chatWindow = null;
  var curWindowHeight = 0;
  for(var i=0;i<this._chatWndsArray.length; i++){
    var chatWindow = this._chatWndsArray[i];
    if(i==this._curWindowIndex){
      if(newCurWindowUid){
        curWindowHeight = this._windowTitleHeight;
          if(chatWindow._curWindMode=="default")
            chatWindow.minimize();
      }
      else
          curWindowHeight = chatWindow._height;
    }
    else if(chatWindow._destuid == newCurWindowUid){
      if(newCurWindowUid){
        newCurWindowIndex = i;
        curWindowHeight = chatWindow._height;
          if(chatWindow._curWindMode=="min"){
            chatWindow.minimize();
          }
      }
      else
          curWindowHeight = this._windowTitleHeight;
    }
    else{
      if(chatWindow._curWindMode=="default")
            chatWindow.minimize();
      curWindowHeight = this._windowTitleHeight;
    }

    leftPos = Math.max(0, rect.x + rect.w-this._windowWidth - this._layoutRight);
    topPos  = Math.max(0, rect.y + rect.h - this._curLayoutTop - curWindowHeight);
    if(im_global.cfg.DebugType==2) dzy_debug.debug("leftPos="+this._layoutRight+", topPos="+this._layoutRight);
    chatWindow.moveTo(leftPos, topPos);
    /*if(im_logger)*/
    /*  im_logger.debug("chatwindow.moveto:"+leftPos+", "+topPos);*/
    this._curLayoutTop += curWindowHeight;
  }
  if(newCurWindowUid && newCurWindowIndex>=0){
    this._curWindowIndex = newCurWindowIndex;
    this._chatWndsArray[this._curWindowIndex]._flash.focus();
  }
}
_p.startMove = function(ev, obj, layout){
    this._saveLayoutRight = this._layoutRight;
    this._saveLayoutBottom = this._layoutBottom;
}
/*x,y移动的相对值*/
_p.dragMove = function(x, y){    
    this._layoutRight = this._saveLayoutRight + x;
    this._layoutBottom = this._saveLayoutBottom + y;
    this.layoutWindow();
}
_p.minCurWindow = function(){
  this._curWindowIndex = -1;
  this.layoutWindow();
}
_p.popinWindow = function(destuid, destnick, chatid){
  this.removePopupWindow(destuid);
  this.addChatWindow(destuid, destnick, chatid, false, null);
  return true;
}
_p.closePopupWindow = function(destuid){
   this.removePopupWindow(destuid);
}
_p.closeAll = function(){
  for(var k in this._chatWnds._hash){
     chatWindow = this._chatWnds._hash[k];
     if(chatWindow)
       chatWindow.close();
  }
}
_p.getChatWindow = function(destuid){
  return this._chatWnds.items(destuid);
}
_p.getPopupWindow = function(destuid){
  return this._popupChatWnds.items(destuid);
}
_p.getCreatingFlashWindow = function(){
  if(this._creatingFlashWnds.length>0){
    var windowDestuid = this._creatingFlashWnds.shift();
    return this.getChatWindow(windowDestuid);
  }
  else
    return null;
}
_p.flashWindowTitle = function(destuid){
    var chatWindow = this.getChatWindow(destuid);
    if(chatWindow){
        titleText =  chatWindow ._isFlashTitle ? chatWindow ._flashTitleText : chatWindow ._titleText;
        chatWindow.changeTitle(titleText);
    }
}
_p.OnTBFocusWindow = function(destuid, x, y){/*点击toolbar 还原聊窗*/
    for(var i=0; i<this._chatWndsArray.length; i++){
        if(this._chatWndsArray[i]._destuid==destuid && this.getChatWindow(destuid)){
            if( !x || !y ){
                this._chatWndsArray[i]._curWindMode = "hide";/*打开已存在的聊窗时*/
                im_toolbar.maxminBtn("MAX");
            }
            y = y-this._chatWndsArray[i]._height;
            this._chatWndsArray[i].MinMax(x, y);
        }else{
            if(this._chatWndsArray[i]._curWindMode == 'default'){
                this._chatWndsArray[i].MinMax();
            }
        }
    }
}
_p.hideFlash= function(){
    for(var i=0; i<this._chatWndsArray.length; i++){
        var tab = im_wdkUtil.$("MINIWINDOW_"+this._chatWndsArray[i]._destuid+"_tab");
        if(arguments[0]){
            tab.style.left = (tab.style.pixelLeft - 1000) + "px";
            if(this._chatWndsArray[i]._curWindMode == 'default'){
                this._chatWndsArray[i]._flash.style.visibility = "hidden";//this._chatWndsArray[i].MinMax();
                for(var j=3;j<8;j++){
                    this._chatWndsArray[i]._self.childNodes[j].style.visibility = "hidden";
                    this._chatWndsArray[i]._self.childNodes[j].style.display = "none";
                }
            }
        }else{
            tab.style.left = (tab.style.pixelLeft + 1000) + "px";
             if(this._chatWndsArray[i]._curWindMode == 'default'){
                this._chatWndsArray[i]._flash.style.visibility = "visible";
                for(var j=3;j<8;j++){
                    this._chatWndsArray[i]._self.childNodes[j].style.visibility = "visible";
                    this._chatWndsArray[i]._self.childNodes[j].style.display = "block";
                }
            }
        }
    }
}

function freeChatSetMyClientID(freeChatFlashGoUrl,presenceFlashGoUrl, destuid, chatid){
   var chatWindow = im_chat_window_manager.getChatWindow(destuid);
   if(chatWindow){
     chatWindow._freeChatFlashGoUrl = freeChatFlashGoUrl;
     chatWindow._presenceFlashGoUrl = presenceFlashGoUrl;
     chatWindow._chatid = chatid;
   }
}

function buddylistSetMyClientID(buddylistFlashGoUrl){
   im_global.temp.buddylistFlashGoUrl = buddylistFlashGoUrl;
}

function webchatFlashReady(destuid){
    var chatWindow = im_chat_window_manager.getChatWindow(destuid);
    if(chatWindow){
      chatWindow.onFlashLoadSuccess();
      /*if(typeof(chatWindow._flash)=="undefined" || !chatWindow._flash)*/
      /*  chatWindow._flash = document.getElementById(chatWindow._flashID);*/
      /*if(chatWindow._flash && chatWindow._flash.setFlashParam){*/
        /*chatWindow._flash.setFlashParam(im_user_sid, im_user_id, im_user_name, im_siteid, chatWindow._destuid, chatWindow._destnick, chatWindow._chatid);*/
                /*alert("chatWindow is opening,destuid:"+chatWindow._destuid+" destnick:"+chatWindow._destnick);*/
       /*}*/
    }
    return true;
}
function buddylistFlashReady(){
    var buddylistFlash = document.getElementById("wdk_buddylist_flash");
    if(buddylistFlash && buddylistFlash.setBuddylistFlashParam){
        buddylistFlash.setBuddylistFlashParam(im_global.variable.user_sid, im_global.variable.user_id, im_global.variable.user_name, im_global.variable.siteid,"buddylist");
    }
}

function setBuddylistFlashParamfunc(){
  var buddylistFlash = document.getElementById("wdk_buddylist_flash");
    if(buddylistFlash && buddylistFlash.setBuddylistFlashParam){
      buddylistFlash.setBuddylistFlashParam(im_global.variable.user_sid, im_global.variable.user_id, im_global.variable.user_name, im_global.variable.siteid,"buddylist");
    }
}

function onGetIMStatus(onlineUserNum, onlineFirendNum){
    /*var imStatusDiv = document.getElementById("wdk_im_status");
    if(imStatusDiv){
        if(onlineUserNum<0) onlineUserNum=0;
        if(onlineFirendNum<0) onlineFirendNum=0;
        imStatusDiv.innerHTML = onlineUserNum+" 在线登录用户";
    }*/
    var miniStateDiv = document.getElementById("wdk_mini_state");
    var miniStateTipDiv = document.getElementById("MiniStateTip");
    var imEntrySpan = document.getElementById("wdk_im_"+im_global.variable.user_id);
    if(im_global.cfg.customparams["enblebuddyentry"])
        tipElement = miniStateDiv;
    else
        tipElement = miniStateDiv?miniStateDiv:imEntrySpan;
    if(tipElement && miniStateTipDiv){
        /*miniStateTipDiv.innerHTML = onlineUserNum+" 在线登录用户，<br/>点击跟在线会员聊天";*/
        /*miniStateTipDiv.innerHTML = "您有"+onlineFirendNum+"个好友，<br/>点击跟好友与在线会员聊天";*/
        /*miniStateTipDiv.innerHTML = "点击跟好友和在线会员聊天";*/
    }
}
/*---toolbar---*/

var WebIM = new Object();
/*----------------------------------------------------------------------*/
//工具条构造函数
WebIM.toolBar = function(ChatWindowManager, BuddylistManager, align, extend){
    this._ChatWindowManager = ChatWindowManager;
    this._BuddylistManager  = BuddylistManager;
    this._align      = align;
    this.extend      = extend;
    this.miniWin     = new Array();
    
    this._left;
    this._top;
    this._right;
    this._bottom;
    this._slef;
    this._height = 25;

    this._Btns = [
            ["im_msg","未读消息","select"],//请不要移动此位置
            //["im_state","状态","select"],
            ["im_copyright","Powered by Ntalker"],
            ["im_setup","设置","select"],
            ["im_buddylist","我的好友","select"],
            ["im_btnZoom","缩放"],
            ["im_btnP","左移"],
            ["im_btnN","右移"]
        ];
    
    this._basepath = im_global.cache.source;//基准URL
    
    this.msgArray = new Array();//未读消息
    this.uid = null;
    this.destuid = '';
    
    this._showMsgMenu = false;

    this._lockMove = false;
    this._speed     = 10;      //速度(毫秒) 
    this._space     = 15;      //每次移动(px) 
    this._pageWidth = 150;     //翻页宽度 
    this._srcTimer  = null;
    this._moveX     = 0;       //总移动距离
};
var _p = WebIM.toolBar.prototype;
_p.init= function(uid){//初始化方法
    this.uid = uid;
    im_wdkUtil.createCSS(this._basepath+'toolbar_' + (this._align=="left" ? "left" : "right") + '_utf8.css');
    
    //添加基准层
    //im_wdkUtil.insertHtml("BeforeEnd", document.getElementsByTagName("body")[0], '<div style="height:25px;border:0px solid #00f"></div>');
    im_wdkUtil.createDom({name:"div",style:"height:25px;border:0px solid #00f"});
    //工具条外框
    //var toolbarElement = im_wdkUtil.insertHtml("BeforeEnd", document.getElementsByTagName("body")[0], '<DIV id="WebIM_xiaoneng" class="im_float" style="z-index:111112;"></DIV>');//overflow: hidden;
    var toolbarElement = im_wdkUtil.createDom({name:"div",id:"WebIM_xiaoneng",_class:"im_float",style:"z-index:111112;"});
    
    //if(document.compatMode=="CSS1Compat" && im_wdkUtil.Browser.msie){
    if(document.compatMode=="CSS1Compat" && im_wdkUtil.Browser.msie && !im_wdkUtil.Browser.msie56){
        im_wdkUtil.createCSS(this._basepath + "tools_ie_utf8.css");
    }
        
    var prot ='<!--Tip SPAN-->';
        prot+='<span style="display:none;"  id="im_show_tip">';
        prot+='<span id="im_show_tip_title"></span>';
        prot+='<span id="im_show_tip_arrow" class="im_arrow"></span>';
        prot+='</span>';
        prot+='<div id="im_btnGroup" class="im_float">';
        prot+='    <ul>';
        //state begin
        prot+='        <li class="tools_button">';
        prot+='            <div id="im_copyright" class="im_copyright"></div>';
        /*
        prot+='            <div id="im_state" style="visibility:;cursor:auto;"></div>';
        prot+='            <div id="im_state_tab" style="display:none;" >';
        prot+='                <div class="tools_menu_opts_header" onclick="im_toolbar.closeAll();">';
        prot+='                    <h2><a onfocus="this.blur()">状态</a></h2>';
        prot+='                </div>';
        prot+='                <div class="btn_menu_list">';
        prot+='                    <ul>';
        prot+='                        <li class="selected"><div class="state_icon1"></div><div class="im_title">在线</div></li>';
        prot+='                        <li><div class="state_icon2"></div><div class="im_title">忙碌</div></li>';
        prot+='                        <li><div class="state_icon2"></div><div class="im_title">离开</div></li>';
        prot+='                        <li><div class="state_icon4"></div><div class="im_title">隐身</div></li>';
        prot+='                    </ul>';
        prot+='                </div>';
        prot+='            </div>';
        */
        prot+='        </li>';
        prot+='        <li class="tools_space"></li>';
        //state end
        //setting begin
        prot+='        <li  class="tools_button">';
        prot+='            <div id="im_setup"></div>';
        prot+='            <div id="im_setup_tab" style="display:none;">';
        prot+='                <div class="tools_menu_opts_header" onclick="im_toolbar.closeAll();">';
        prot+='                    <h2><a onfocus="this.blur()">设置</a></h2>';
        prot+='                </div>';
        prot+='                <div id="im_setup_tab_con" class="btn_menu_list"></div>';
        prot+='            </div>';
        prot+='        </li>';
        prot+='        <li class="tools_space"></li>';
        //state begin
        //buddylist begin
        prot+='        <li class="tools_button"><div id="im_buddylist"></div><div id="im_buddylist_tab" style="display:"></div></li>';
        prot+='        <li class="tools_space"></li>';
        //buddylist end
        
        //自定义工具条按钮
        var toolbarButtons = im_global.cfg.customtoolbarButtons;
        for(var i=0; i<toolbarButtons.length;i++){
            prot+='        <li class="tools_button" >';
            prot+='            <div id="'+toolbarButtons[i].id+'" class="'+toolbarButtons[i]._class+'">';
            prot+='<a href="' + toolbarButtons[i].url + '" class="'+toolbarButtons[i]._class+'" target="_blank">' + toolbarButtons[i].con + '</a>';
            prot+='            </div>';
            prot+='            <div style="display:"></div>';
            prot+='        </li>';
            prot+='        <li class="tools_space"></li>';
            this._Btns.push([toolbarButtons[i].id, toolbarButtons[i].tip]);
        }
        
        //新消息 begin
        prot+='        <li class="tools_button">';
        prot+='            <div id="im_msg">0</div>';
        prot+='            <div id="im_msg_tab"  style="display:none;">';
        prot+='                <div class="tools_menu_opts_header" onclick="im_toolbar.closeAll();">';
        prot+='                    <h2><a onfocus="this.blur()">系统消息</a></h2>';
        prot+='                </div>';
        prot+='                <div class="btn_menu_list">';
        prot+='                    <ul id="im_msg_list">';
        
        prot+='                    </ul>';
        prot+='                </div>';
        prot+='            </div>';
        prot+='        </li>';
        prot+='        <li class="tools_space" id="btnspace0"></li>';
        //新消息 end        
        
        prot+='        <li id="im_chatboxnumli" class="tools_button" style="width:80px;"><div id="im_chatboxnum" style="color:'+im_global.win.tbfontcolor+';">聊天窗口[0]</div></li>';
        prot+='    </ul>';
        prot+='</div>';
        //缩放
        prot+='<div class="im_float tools_space"></div>';
        prot+='<div class="im_float" style="width:20px;position:relative"><div id="im_btnZoom"></div></div>';
        
        //按钮 
        prot+='<div class="im_float tools_space" id="btnspace1"></div>';
        prot+='<div class="im_float" style="width:30px;position:relative"><div id="im_btnP"></div></div>';
        //miniWin
        prot+='<div class="im_float tools_space" id="btnspace2"></div>';
        prot+='<div class="im_float" id="im_miniWinArea">';
        prot+='    <div id="im_chatwindow_ScrCont" style="right">';
        prot+='        <div id="im_list">';
        prot+='            <ul id="im_miniWinGp">';
        
        prot+='            </ul>';
        prot+='        </div>';
        prot+='    </div>';
        prot+='</div>';
        //按钮
        prot+='<div class="im_float tools_space" id="btnspace3"></div>';
        prot+='<div class="im_float" style="width:30px;position:relative"><div id="im_btnN"></div></div>';

    toolbarElement.innerHTML = prot;
    delete prot;
    im_wdkUtil.$("im_btnGroup").style.width = (toolbarButtons.length*33 + 140) + "px";
    
    if(this._align=="left"){
        im_wdkUtil.$("im_btnP").className = "im_btnP";
        im_wdkUtil.$("im_btnN").className = "im_btnN";
    }else{
        im_wdkUtil.$("im_btnP").className = "im_btnN";
        im_wdkUtil.$("im_btnN").className = "im_btnP";
    }
    if(this.extend)    this.maxmize(true);
    else     this.minimze(true);
    this._loadMsg();//载入未读消息
    wdkApplication._FloatWindowManager.addWindow(this);  /*注册该窗体*/
    
    var _this = this;
    var __selectEventHandle = function(ev){_this.selectEventHandle(ev || window.event);};
    var __clickEventHandle  = function(ev){_this.clickEventHandle(ev || window.event);};
    var __eventOverOut = function(ev){_this._eventOverOut(ev || window.event)};
    var __eventResize = function(ev){if(_this.extend){_this.minimze();_this.maxmize();}}
    
    for(var i=0;i<_this._Btns.length;i++){//兼听TOOLBAR按钮
        if(this._align=="right" && _this._Btns[i][0]=="im_btnP"){
            var btnNtxt           = _this._Btns[i][1];
            _this._Btns[i][1]     = _this._Btns[(i+1)][1];
            _this._Btns[(i+1)][1] = btnNtxt;
        }
        
        var _el = im_wdkUtil.$(_this._Btns[i][0]);
        if(_this._Btns[i][2]=="select")
            im_wdkUtil.Event.addEvent(_el, "click", __selectEventHandle);
        else{
            im_wdkUtil.Event.addEvent(_el, "click", __clickEventHandle);
            im_wdkUtil.Event.addEvent(_el, "mousedown", __clickEventHandle);
            im_wdkUtil.Event.addEvent(_el, "mouseup", __clickEventHandle);
        }
        
        im_wdkUtil.Event.addEvent(_el, "mouseover", __eventOverOut);
        im_wdkUtil.Event.addEvent(_el, "mouseout", __eventOverOut);
    }
    im_wdkUtil.Event.addEvent(window, "resize", __eventResize);
    this.fooRepos();
}

_p.fooRepos = function(ev){//toolbar 整体定位
    var oElem = im_wdkUtil.$("WebIM_xiaoneng");
    if( (document.compatMode=="BackCompat" && im_wdkUtil.Browser.msie) ||
        (document.compatMode=="CSS1Compat" && im_wdkUtil.Browser.msie56) ){
        var _rect = im_wdkUtil.viewRect.get(window,true);
        oElem.style.position='absolute';
        oElem.style.top = (_rect.y + _rect.h - 28) + 'px';
    }/*
    if(document.compatMode=="CSS1Compat" && im_wdkUtil.Browser.msie56){
        if(this._align=="left")
            oElem.style.left = "0px";
        else{
            oElem.style.right = "18px";//oElem.style.right = (im_wdkUtil.doc.scrollHeight>im_wdkUtil.doc.clientHeight ? 18 : 0) + 'px';
        }
    }*/
}
//最大模式
_p.maxmize=function(){
    var _rect         = im_wdkUtil.viewRect.get(window, true);
    var btnGRect      = im_wdkUtil.viewRect.get('im_btnGroup');
    var chatLINumRect = im_wdkUtil.viewRect.get("im_chatboxnumli");
    im_wdkUtil.$("WebIM_xiaoneng").style.width    = "100%";
    im_wdkUtil.$("im_btnGroup").style.width       = (btnGRect.w-chatLINumRect.w-3) + "px";
    im_wdkUtil.$("im_btnZoom").className          = "im_btnZoom";
    im_wdkUtil.$("im_chatboxnumli").style.display = "none";
    
    im_wdkUtil.$("btnspace0").style.display       = "none";
    im_wdkUtil.$("btnspace1").style.display       = "";
    im_wdkUtil.$("btnspace2").style.display       = "";
    im_wdkUtil.$("btnspace3").style.display       = "";
    im_wdkUtil.$("im_btnP").style.display         = "";
    im_wdkUtil.$("im_btnN").style.display         = "";
    
    var AreaWidth = _rect.w - im_wdkUtil.$("im_btnGroup").offsetWidth - 120;
    im_wdkUtil.$('im_miniWinArea').style.visibility = "visible";
    if(im_wdkUtil.Browser.msie56) im_wdkUtil.$('im_miniWinArea').style.display    = "";
    im_wdkUtil.$('im_miniWinArea').style.width      = AreaWidth + "px";
    
    im_chat_window_manager.hideFlash(false);
}
//缩小模式    
_p.minimze = function(){
    if(arguments[0])
        im_chat_window_manager.OnTBFocusWindow(0);
    
    im_chat_window_manager.hideFlash(true);
    
    var _ext = this._align=="left" ? 2 : 0;
    im_wdkUtil.$("im_chatboxnumli").style.display = "block";
    var btnGRect      = im_wdkUtil.viewRect.get("im_btnGroup");
    var chatLINumRect = im_wdkUtil.viewRect.get("im_chatboxnumli");
    im_wdkUtil.$('im_btnGroup').style.width       = (btnGRect.w+chatLINumRect.w+3+_ext) + "px";
    im_wdkUtil.$('WebIM_xiaoneng').style.width    = (btnGRect.w+chatLINumRect.w+27+_ext) + "px";
    im_wdkUtil.$('im_btnZoom').className          = "im_btnZoom_mini";
    
    im_wdkUtil.$("btnspace0").style.display       = "";
    im_wdkUtil.$("btnspace1").style.display       = "none";
    im_wdkUtil.$("btnspace2").style.display       = "none";
    im_wdkUtil.$("btnspace3").style.display       = "none";
    im_wdkUtil.$("im_btnP").style.display         = "none";
    im_wdkUtil.$("im_btnN").style.display         = "none";
    
    im_wdkUtil.$('im_miniWinArea').style.visibility = "hidden";
    if(im_wdkUtil.Browser.msie56) im_wdkUtil.$('im_miniWinArea').style.display    = "none";
    im_wdkUtil.$('im_miniWinArea').style.width      = "1px";
    if(this._align=="left"){
        im_wdkUtil.$('WebIM_xiaoneng').style.borderRight="1px solid "+im_global.cfg.broderColor;
    }else if(this._align=="right"){ 
        im_wdkUtil.$('WebIM_xiaoneng').style.borderLeft="1px solid "+im_global.cfg.broderColor;
    }
}

_p.maxminBtn = function(){//缩放按钮点击处理
    if(arguments[0]=="MAX" && this.extend)
        return;
    if(!this.extend){
        this.maxmize();
        this.extend = true;
        im_global.cfg.customparams["intact"] = true;
    }else{
        this.minimze();
        this.extend = false;
        im_global.cfg.customparams["intact"] = false;
    }
}
//添加聊天窗口
_p.OnAddChatWindow = function(destuid,destname,isautofocus){
    for(i=0;i<this.miniWin.length;i++){
        if(this.miniWin[i].destuid==destuid){
            return ;
        }
    }
    for(var i=0; i<this.miniWin.length; i++){
        this.miniWin[i].onBlur();
    }
    var newMiniWindow = new WebIM.toolBar.miniWindow(destuid,destname,isautofocus, this);
    var miniWindowDOM = newMiniWindow.OnAddChatWindow();
    this.miniWin.push(newMiniWindow);
    im_wdkUtil.$("im_chatboxnum").innerHTML = "聊天窗口[" + this.miniWin.length + "]";
    
    this.maxminBtn("MAX");
    if(this._align=="left"){
        this.rightMove();
    }else{
        this.leftMove();
    }
    
    var _Area       = im_wdkUtil.$("im_miniWinArea");
    var _mWinRect   = im_wdkUtil.viewRect.get(newMiniWindow._self);
    var _Rect       = im_wdkUtil.viewRect.get(window, true);
    
    if(this._align=="left")
        newMiniWindow._x = _mWinRect.x - _Area.scrollLeft;
    else
        newMiniWindow._x = _mWinRect.x+_mWinRect.w;
    newMiniWindow._y = _mWinRect.y;
    
    return {x:newMiniWindow._x, y:newMiniWindow._y,o:miniWindowDOM};//居左,取左上|居右取右上座标
}
_p.OnRemoveChatWindow=function(destuid){//关闭聊天窗口
    var _mWin = im_wdkUtil.$("MINIWINDOW_" + destuid);
    if(_mWin){
        _mWin.parentNode.removeChild(_mWin);
        for(var i=0;i<this.miniWin.length;i++){
            if(this.miniWin[i]._destuid==destuid){
                if(i-1 >= 0)
                    var Ndestuid = this.miniWin[(i-1)]._destuid;
                else if(i+1 < this.miniWin.length)
                    var Ndestuid = this.miniWin[(i+1)]._destuid;
                this.miniWin.splice(i,1);
                im_wdkUtil.$("im_chatboxnum").innerHTML = "聊天窗口[" + this.miniWin.length + "]";
                if(this._align=="left"){
                    this.leftMove();
                }else{
                    this.rightMove();
                }
                if(Ndestuid){
                    var _rect  = im_wdkUtil.viewRect.get("MINIWINDOW_" + Ndestuid);
                    var _x     = this._align=="left" ? (_rect.x - im_wdkUtil.$("im_miniWinArea").scrollLeft) : 
                                                        _rect.x+_rect.w;
                    var _y     = _rect.y;
                    im_chat_window_manager.OnTBFocusWindow(Ndestuid, _x, _y);
                }
                return;
            }
        }
    } 
    
}
_p.OnChatWindowMinize = function(destuid){/*miniWindow状态改变*/
}
_p.getMiniWindow = function(destuid){
    for(var i=0; i<this.miniWin.length; i++){
        if(this.miniWin[i]._destuid == destuid)
            return this.miniWin[i];
    }
}
_p._showBuddylist = function(ev, show){//OnRemoveBuddylistWindow
    var ev = ev || window.event;
    var _El = ev.srcElement || ev.target;
    var _rect = im_wdkUtil.viewRect.get(_El);
    var _x = this._align=="left" ? _rect.x : _rect.x+_rect.w ;
    var _y = _rect.y;
    im_myIMWindow.OnTBShowBuddylist(_x, _y, show);
}
_p.selectEventHandle=function(ev){//选中打开菜单事件
    var oTarget = ev.target || ev.srcElement;
    var _Btns = this._Btns;
    
    for(var i=0; i<_Btns.length; i++){
        var _Menu = im_wdkUtil.$(_Btns[i][0]+"_tab");
        if(_Btns[i][2]=="select"){
            if(_Btns[i][0] == oTarget.id && _Menu.style.display!="block"){
                oTarget.className = "focused";
                _Menu.style.display  = "block";
                if(_Btns[i][0]=="im_buddylist") this._showBuddylist(ev, true);
                if(_Btns[i][0]=="im_setup") im_toolBar_Menu.showMenu(oTarget);
                if(_Btns[i][0]=="im_msg") this._showMsgPanel(ev);
            }else{
                oTarget.className = "";
                _Menu.style.display = "none";
                if(_Btns[i][0]=="im_buddylist") this._showBuddylist(ev, false);
                if(_Btns[i][0]=="im_setup") im_toolBar_Menu.hiddenMenu();
                //if(_Btns[i][0]=="im_msg") this._showMsgPanel(ev);
            }
        }
    }
    im_wdkUtil.$('im_show_tip').style.display = "none";
}
_p.clickEventHandle = function(ev){//点击按钮
    var oTarget = ev.target || ev.srcElement;
    var _Btns = this._Btns;
    if(ev.type=="click"){
        //if(oTarget.id=="im_buddylist") this._showBuddylist(ev);
        if(oTarget.id=="im_btnZoom") this.maxminBtn();
        if(oTarget.id=="im_copyright") window.open("http://www.ntalker.com","Ntalker");
        im_wdkUtil.$('im_show_tip').style.display = "none";
    }else if(ev.type=="mousedown"){
        if(oTarget.id=="im_btnN"){
            if(this._align=="left")
                this.rightMove();
            else
                this.leftMove();
        }
        if(oTarget.id=="im_btnP"){
            if(this._align=="left")
                this.leftMove();
            else
                this.rightMove();
        }
    }
}
_p.leftMove = function(){
    if(this._moveX) return;
    
    var _Area    = im_wdkUtil.$("im_miniWinArea");
    var grpWidth = this._pageWidth*im_wdkUtil.$("im_miniWinGp").getElementsByTagName("LI").length;
    var _conRect = im_wdkUtil.viewRect.get("im_chatwindow_ScrCont");
    var browser  = im_wdkUtil.Browser;
    
    var outNum = Math.ceil((grpWidth-_Area.offsetWidth)/this._pageWidth);
    if( (0-_Area.scrollLeft < outNum*this._pageWidth &&  this._align=="right" && (browser.firefox || browser.opera) ) ||
        (_Area.scrollLeft>=0 && this._align=="left") ||
        (this._align=="right" && (_Area.scrollLeft<=_conRect.w-_Area.offsetWidth && _Area.scrollLeft >= _conRect.w - grpWidth) ) 
      ){ this._left();}
}
_p._left = function(){
    var _Area    = im_wdkUtil.$("im_miniWinArea");
    
    if( this._moveX<this._pageWidth ){
        _Area.scrollLeft -= this._space;
        this._moveX      += this._space;
        window.setTimeout("im_toolbar._left()", this._speed);
    }else{
        this._moveX = 0;
    }
}
_p.rightMove = function(){
    if(this._moveX) return;
    var _Area    = im_wdkUtil.$("im_miniWinArea");
    var grpWidth = this._pageWidth*im_wdkUtil.$("im_miniWinGp").getElementsByTagName("LI").length;
    var _conRect = im_wdkUtil.viewRect.get("im_chatwindow_ScrCont");
    var browser  = im_wdkUtil.Browser;

    if( (_Area.scrollLeft < 0 && this._align=="right" && (browser.firefox || browser.opera)) || 
        (grpWidth-_Area.offsetWidth > _Area.scrollLeft && this._align=="left" && !(browser.firefox || browser.opera)) || 
        (this._align=="right" && _Area.scrollLeft < _conRect.w-_Area.offsetWidth && !(browser.firefox || browser.opera))
      ){this._right();}
}
_p._right = function(){
    var _Area    = im_wdkUtil.$("im_miniWinArea");
    
    if( this._moveX<this._pageWidth ){
        _Area.scrollLeft += this._space;
        this._moveX      += this._space;
        window.setTimeout("im_toolbar._right()", this._speed);
    }else{
        this._moveX = 0;
    }
}
_p._eventOverOut = function(ev){
    var oTarget = ev.target || ev.srcElement;
    var _Btns = this._Btns;
    
    var _tipEl    = im_wdkUtil.$('im_show_tip');
    var _tipArrow = im_wdkUtil.$('im_show_tip_arrow');
    if(ev.type=="mouseover"){
        for(var i=0;i<_Btns.length;i++){
            var _tip = _Btns[i][1];
            if( im_wdkUtil.$(_Btns[i][0]).className != "focused" && _tip && 
                (_Btns[i][0]==oTarget.id || _Btns[i][0]==oTarget.parentNode.id) ){
                oTarget.parentNode.appendChild(_tipEl);
                _tipEl.style.width = _Btns[i][0]=="im_copyright" ? "120px" : "70px";
                im_wdkUtil.$("im_show_tip_title").innerHTML = _tip ? _tip : "";
                _tipEl.style.display = "block";
                var _btnRect = im_wdkUtil.viewRect.get(oTarget);
                var _tipRect = im_wdkUtil.viewRect.get(_tipEl);
                
                if(_btnRect.x<_tipRect.w-_btnRect.w/2-10){
                    _tipEl.style.left   = (_btnRect.w/2 - 10) + "px";
                    _tipArrow.className = "im_arrow_exp";
                    _tipArrow.style.left = (_btnRect.w/2 - 10) + "px";
                }else{
                    _tipEl.style.left  = (_btnRect.w/2 + 10 - _tipRect.w) + "px";
                    _tipArrow.className = "im_arrow";
                    _tipArrow.style.left = (im_wdkUtil.viewRect.get(_tipEl).w - _btnRect.w/2) + "px";
                }
                break;
            }
        }
    }else{
        _tipEl.style.display = "none";
    }
    oTarget.style.backgroundColor = ev.type=="mouseover" ? im_global.cfg.toolbarOverColor : "";
}
_p.getMiniWinPos = function(destuid){
    var _Area       = im_wdkUtil.$("im_miniWinArea");
    for(var i=0;i<this.miniWin.length;i++){
        if(this.miniWin[i]._destuid==destuid){
            var _miniRect = im_wdkUtil.viewRect.get(im_wdkUtil.$("MINIWINDOW_"+destuid));
            var newMiniWindow = {_x:0, _y:0};
            //居左,取左上|居右取右上座标
            if(this._align=="left")
                newMiniWindow._x = _miniRect.x-_Area.scrollLeft;
            else
                newMiniWindow._x = _miniRect.x+_miniRect.w;
            newMiniWindow.y = _miniRect.y;
            return newMiniWindow;
        }
    }
}
_p.closeAll=function(){
    this._showMsgMenu = false;
    var _Btns = this._Btns;
    for(var i=0;i<_Btns.length;i++){
        if(_Btns[i][2]=="select"){
            im_wdkUtil.$(_Btns[i][0]).className="";
            var _Menu = im_wdkUtil.$(_Btns[i][0]+"_tab");
            _Menu.style.display = "none";
            if(_Btns[i][0]=="im_setup") im_toolBar_Menu.hiddenMenu();
        }
    }
    return true;
}
_p._loadMsg = function(){/*消息相关方法*/
    var key = "IM_UnRead_Message";
    var val = im_wdkUtil.GetCookie(key);
    if(val==null||typeof(val)=='undefined'||val=="") return;
    
    var _Msg= val.split("}:{");
    var uid = this.uid;
    var t   = [];
    for(var i=0; i<_Msg.length; i++){
        var _v = _Msg[i];
        if(typeof(_v)=='undefined' || _v==null || _v=="") break;
        t.push(_v.split(","));//[uid, destuid, destnick, message, _type, chatid, isautofocus, content]
    }
    this.msgArray = t;
    //this._Btns[0][1] = t.length+"条未读消息"
    
    im_wdkUtil.$("im_msg").innerHTML = t.length;
}
_p.saveMsg = function(){
    var key = "IM_UnRead_Message";
    var val = "";
    var uid = this.uid;
    var _im_destuids="";
    var _msgArray = this.msgArray;
    for(var i=0; i<_msgArray.length; i++){
        val += _msgArray[i].join(",") + (i+1<_msgArray.length ? "}:{" : "");
    }
    im_wdkUtil.SetCookie(key, val);
}
_p._showMsgPanel = function(){
    this._showMsgMenu = true;
    var _msgArray = this.msgArray;
    var msgListUL= im_wdkUtil.$("im_msg_list");
    var msgBtn   = im_wdkUtil.$("im_msg");
    msgListUL.innerHTML = '';//im_wdkUtil.removeChild(msgListUL, "LI");
    
    if(_msgArray.length<=0){
        var _oLI = im_wdkUtil.createDom({name:"LI",mouseover:"this.className='selected';",mouseout:"this.className='';"}, msgListUL);
        if(im_wdkUtil.Browser.firefox){
            var msgDIV = im_wdkUtil.createDom({name:"DIV",className:"sys_msg"}, _oLI);
            var titDIV = im_wdkUtil.createDom({name:"DIV",className:"im_title"}, _oLI);
            im_wdkUtil.createDom({name:"Text",text:"暂无消息"}, titDIV);
        }else{
            im_wdkUtil.insertHtml("beforeEnd", _oLI, '<DIV class="sys_msg"></DIV><DIV class="im_title">暂无消息</DIV>');
        }
        //this._Btns[0][1] = "0条未读消息"
        msgBtn.innerHTML = "0";
    }else{
        for(var i=0; i<_msgArray.length; i++){
            var _v = _msgArray[i];//[uid, destuid, destnick, message, _type]
            var className = _v[4]=="2" ? "sys_msg" : _v[4]=="1" ? "sys_msg_addfriend" : "sys_msg";
            var _oLI = im_wdkUtil.createDom({name:"LI",mouseover:"this.className='selected';",mouseout:"this.className='';",click:"im_toolbar._viewMsg('"+_v[1]+"', "+_v[4]+")"}, msgListUL);
            
            if(im_wdkUtil.Browser.firefox){
                var msgDIV = im_wdkUtil.createDom({name:"DIV",className:_className}, _oLI);
                var titDIV = im_wdkUtil.createDom({name:"DIV",className:"im_title"}, _oLI);
                im_wdkUtil.createDom({name:"Text",text:_v[3]}, titDIV);
            }else{
                im_wdkUtil.insertHtml("beforeEnd", _oLI, '<DIV class="'+className+'"></DIV><DIV class="im_title">'+_v[3]+'</DIV>');
            }
        }
        //this._Btns[0][1] = _msgArray.length+"条未读消息"
        msgBtn.innerHTML = _msgArray.length;
    }
}
_p._viewMsg = function(destuid, typ, newWin){
    newWin = typeof(newWin)=="undefined"||newWin ? true : false;
    var _Msg = this.msgArray;
    for(var i=0; i<_Msg.length; i++){ //[uid, destuid, destnick, message, _type, chatid, isautofocus, content];
        if(destuid==="all"){
            this.deleteMsg(_Msg[i][1]);
        }else if(_Msg[i][1] == destuid && typ==_Msg[i][4])
            var _v = _Msg[i];
    }
    if(!_v) return;
    if(_v[4]==1 && newWin){
        OnPresenceReceiveAddFriend(_v[1], _v[2], true);
    }else  if(_v[4]==2 && newWin){
        this._ChatWindowManager.addChatWindow(_v[1], _v[2], _v[5], _v[6], _v[7]);
    }
    this.deleteMsg(destuid);
}
_p.addMsg = function(destuid, destnick, message, type, chatid, isautofocus, content){//type[0:sys,1:addfir,2:info]
    var uid = this.uid;
    var _add = true;
    var _Msg = this.msgArray;
    var _type = type ? type : 0;
    for(var i=0; i<_Msg.length; i++){
        if(_Msg[i][1]==destuid && _Msg[i][4]==_type){//同一条只提示一次
            _add = false;
        } 
    }
    if(_add)
        _Msg.push([uid, destuid, destnick, message, _type, chatid, isautofocus, content]);
    var _s    = _Msg.length>10 ? _Msg.length-10 : 0;
    var _tMsg = _Msg.slice(_s, _Msg.length);
    //this._Btns[0][1] = _tMsg.length+"条未读消息"
    im_wdkUtil.$("im_msg").innerHTML = _tMsg.length;
    this.msgArray = _tMsg;
    
    if(this._showMsgMenu) this._showMsgPanel();
}
_p.deleteMsg = function(destuid){
    var uid = this.uid;
    var _Msg = this.msgArray;
    var t = new Array();
    for(var i=0; i<_Msg.length; i++){
        if( _Msg[i][1] != destuid ) t.push(_Msg[i]);
    }
    this.msgArray = t;
    this._showMsgPanel();
    if(t.length==0)
        im_wdkUtil.$("im_msg_tab").style.display='none';
}

WebIM.toolBar.miniWindow = function(destuid,destname,isautofocus, objToolBar){
    this._toolbar    = objToolBar;
    
    this._self       = null;
    this.isautofocus = isautofocus;
    this._destuid    = destuid;
    this._destnick   = destname ? destname : "";
    this._tab        = null;
    this._x;
    this._y;
    this._width      = this._toolbar._pageWidth;
    this._focus      = isautofocus ? true : false;
    this._align      = this._toolbar._align;
    
    this.originTitle = "";
    this.promptMsg   = "";
    this.timerID     = null;
    this._stopFlash  = false;
    this.counter     = 0;
}
_p = WebIM.toolBar.miniWindow.prototype;
_p.OnAddChatWindow = function(){
    var _parm = {name:"LI",
                id:"MINIWINDOW_"+this._destuid,
                _class:(this._focus ? "minimsgclick" : "minimsg"),
                style:"cursor:pointer;color:"+im_global.win.tbfontcolor+";"};
    var oli    = im_wdkUtil.createDom(_parm, im_wdkUtil.$('im_miniWinGp'), "beforeEnd");
    this._self = oli;
    this.originTitle = im_wdkUtil.cutText(this._destnick+'-对话', 9);
    
    if(im_wdkUtil.Browser.firefox){
        im_wdkUtil.createDom({name:"DIV",id:"MINIWINDOW_"+this._destuid+"_tab",style:"width:auto;height:auto;position:absolute;outline-style:none"}, oli);
        im_wdkUtil.createDom({name:"text",text:this.originTitle}, oli);
    }else{
        var _html = '<DIV id="MINIWINDOW_'+this._destuid+'_tab" style="width:auto;height:auto;position:absolute;outline-style:none"></DIV>'+this.originTitle;
        im_wdkUtil.insertHtml("beforeend", oli, _html);
    }
    var _this   = this;
    function __clickWindow(ev){_this._stopFlash = true;_this._clickWindow(ev);}
    function __mouseEvent(ev){_this._mouseEvent(ev);}
    im_wdkUtil.Event.addEvent(oli, "click",     __clickWindow);
    im_wdkUtil.Event.addEvent(oli, "mouseover", __mouseEvent);
    im_wdkUtil.Event.addEvent(oli, "mouseout",  __mouseEvent);

    return oli;
}
_p.onFocus = function(){
    var _miniWindows = this._toolbar.miniWin;
    for(var i=0; i<_miniWindows.length; i++){
        _miniWindows[i]._self.className = "minimsg";
        _miniWindows[i]._focus = false;
    }
    this._self.className = "minimsgclick";
    this._focus = true;
}
_p.onBlur = function(){
    this._self.className = "minimsg";
    this._focus = false;
}
_p.onReceiveMiniMessage=function(message){
    var titleText = "说:"+message;
    this.startFlashTitle(titleText);

}  
_p.startFlashTitle = function(titleText){
    if(this.timerID)
        return;
    this.promptMsg = im_wdkUtil.cutText(titleText,9);
    this.timerID   = setInterval("im_toolbar.getMiniWindow('"+this._destuid+"').flashWindowTitle()",1000);
};
_p.flashWindowTitle = function(){
    if(this._focus){
        im_wdkUtil.$("MINIWINDOW_"+this._destuid).childNodes[1].nodeValue = this.originTitle;
        this._self.className = "minimsg";
        clearInterval(this.timerID);
        this.timerID = null;
        this.counter = 0;
        return;
    }
    this.counter++;
    if(this.counter%2==0){
        im_wdkUtil.$("MINIWINDOW_"+this._destuid).childNodes[1].nodeValue = this.originTitle;
        this._self.className = "minimsg";
    }
    else{
        im_wdkUtil.$("MINIWINDOW_"+this._destuid).childNodes[1].nodeValue = this.promptMsg;
        this._self.className = "minimsgclick";
    }
}

_p._clickWindow = function(ev){
    var ev     = ev || window.event;
    var El     = ev.target || ev.srcElement;
    if(El.tagName!="LI") return;
    
    var _rect  = im_wdkUtil.viewRect.get(El);
    var _x     = this._align=="left" ? (_rect.x - im_wdkUtil.$("im_miniWinArea").scrollLeft) : 
                                        _rect.x+_rect.w;
    var _y = _rect.y;
    im_chat_window_manager.OnTBFocusWindow(this._destuid, _x, _y);
}
_p._mouseEvent = function(ev){
    var ev = ev || window.event;
    var El = ev.target || ev.srcElement;
    if(El.tagName=="LI")
        El.className = ev.type=="mouseover" ? "minimsgover" : this._focus ? "minimsgclick" : "minimsg";
}

WebIM.IM_Menu = function(){
    __this = this;
    this._win = window;
    this._doc = window.document;
    this._body = document.body || document.documentElement;
    this._rootElement = null;
    this._floatpos = "";
    this._Menu;
    this._Fun;
    this._objName;
    this._show = false;
    
    this._width = 115;
    this._height = 15;
    
    this.settingItem;
    this.settingValue;
}
var _p = WebIM.IM_Menu.prototype;
_p.init = function(_Function, _Name){
    this._Fun        = _Function;
    this._objName    = _Name;
    this._hoverColor = im_global.cfg.toolbarOverColor;
    
    this._parentNode = document.getElementById('im_setup_tab_con');
    this._nameID     = "IM_SET_Menu";
    this.settingItem = im_global.variable.setingItems;
    this._align      = im_global.cfg.customparams['floatpos'];
}
_p.showMenu = function(BtnEl){
    this._BtnEl = BtnEl;
    var _presenceFlash = im_wdkUtil.$("impresenceflash");
    if(_presenceFlash && _presenceFlash.GetUserSettings){
        this.settingValue = _presenceFlash.GetUserSettings();
        if(im_global.cfg.DebugType==2 )dzy_debug.debug("载入的数据："+this.settingValue);
        this.settingValue = im_wdkUtil.StringToArray(this.settingValue);
    }
    this._createMenu(this._parentNode, this._nameID, this.settingItem);
    this._show = true;
}
_p.hiddenMenu = function(){
    if(this._BtnEl) this._BtnEl.className = "";
    this._parentNode.parentNode.style.display = "none";
    im_wdkUtil.removeChildNodes(this._parentNode);
    this._parentNode.innerHTML = '';
    this._show = false
    this._rootElement = null;
}
_p._createMenu = function(_parentNode, nameid, parameter){
    if(!im_wdkUtil.isArray(parameter)) return;
    
    var rect = im_wdkUtil.viewRect.get(window, true);
    var parentRect = im_wdkUtil.viewRect.get(_parentNode);
    
    var MenuUL = im_wdkUtil.$(nameid);
    if(!MenuUL){
        MenuUL = this._doc.createElement("UL");
        MenuUL.id  = nameid;
    }
    if(!this._Menu) this._Menu = MenuUL;
    im_wdkUtil.removeChildNodes(MenuUL);
    MenuUL.innerHTML = '';
    if(this._rootElement){//二级菜单
    	var ulSty = MenuUL.style;
	ulSty.listStyle = "none";
        ulSty.margin    = "-1px 1px";
        ulSty.cursor    = "pointer";
        ulSty.padding   = "0px";
        ulSty.border    = "1px solid #ccc";
        ulSty.width     = this._width + "px";
        ulSty.position  = "absolute";
        ulSty.zIndex    = 990;
        ulSty.display   = this._rootElement ? "none" : "block";
    }else{
        MenuUL.style.zIndex = 999;
        MenuUL.style.display= "block";
    }
   
    if(!this._rootElement) this._rootElement = _parentNode;
    for(var i=0; i<parameter.length; i++){
        var newMenu = this._addItem(MenuUL, parameter[i]);
        this._createMenu(newMenu, nameid+"_"+i, parameter[i].value);
    }
    _parentNode.appendChild(MenuUL);
}
_p._addItem = function(MenuUL, parameter){
    if(!MenuUL) return;
    var config = this.settingValue;
    
    var _event = parameter.title=="-" ? '' : (!im_wdkUtil.isArray(parameter.value) ? ' onclick="'+this._objName+'._clickMenu(this)"' : '')+' onmouseover="'+this._objName+'._actionMenu(this,true)" onmouseout="'+this._objName+'._actionMenu(this)"';
    MenuUL.innerHTML += (parameter.title=="-" ?     '<LI' + _event + ' style="font-size:0px;margin-top:2px;margin-bottom:2px;border-top:1px solid #fff;border-bottom:1px solid #ccc;height:0px;"></LI>' : 
                         parameter.type=="MENU" ?   '<LI' + _event + ' ><div class="icon_no"></div><div class="im_title">' + parameter.title + '</div><span>&raquo;</span></LI>' :
                         parameter.type=="URL" ?    '<LI' + _event + ' ><div class="icon_no"></div><div class="im_title"><A href="' + parameter.value + '" target="_blank">' + parameter.title + '</A></div></LI>' :
                         parameter.type=="option" ? '<LI' + _event + ' ><div class="icon_no"></div><div class="im_title">' + parameter.title + '</div><span>...</span></LI>' :
                         parameter.type=="radio" ?  '<LI' + _event + ' class="'+(config[parameter.name]==parameter.value ? 'selected ' : '')+'"><div class="'+(config[parameter.name]==parameter.value ? 'icon_o ' : 'icon_no')+'" ></div><INPUT  name="'+parameter.name+'" type="radio" value="' + parameter.value + '"' + (config[parameter.name]==parameter.value ? ' checked ' : '') + ' /><div class="im_title" >' + parameter.title + '</div></LI>' :
                         parameter.type=="checkbox" ? '<LI' + _event + ' class="'+(!config[parameter.name]||config[parameter.name]=="false" ? '' : 'selected')+'"><div class="'+(!config[parameter.name]||config[parameter.name]=="false" ? 'icon_no' : 'icon')+'" ></div><INPUT name="'+parameter.name+'" value="' + parameter.value + '" type="checkbox"' + (!config[parameter.name]||config[parameter.name]=="false" ? '' : ' checked') + ' /><div class="im_title">' + parameter.title + '</div></LI>' :
                        "");
    this._updatePos();
    var _MenuLIs = MenuUL.getElementsByTagName('LI');
    var _MenuLI  = _MenuLIs[(_MenuLIs.length-1)];
    /*
    if(parameter.type=="option" && im_wdkUtil.isFunction(parameter.value)){
        _MenuLI.onclick = function(ev){parameter.value(ev||window.event);}
    }*/
    return _MenuLI;
}
_p._actionMenu = function(MenuLI, visible){
    MenuLI.style.backgroundColor = visible ? this._hoverColor : "";
    var childMenu = MenuLI.getElementsByTagName("UL")[0];
    if(childMenu){
        var _rect = im_wdkUtil.viewRect.get(MenuLI);
        childMenu.style.left = this._align=="left" ? (_rect.w) +"px": (0-_rect.w-4) + "px";
        childMenu.style.top = "0px";
        childMenu.style.display = visible ? "block" : "none";
    }
}
_p._clickMenu = function(MenuLI){
    var _INPUT = __this._rootElement.getElementsByTagName('INPUT');
    var _N_MenuLI = MenuLI.getElementsByTagName('INPUT')[0];
    if(!_N_MenuLI) return;
    var _tempDate = "";
    _N_MenuLI.checked = _N_MenuLI.type=="checkbox" ? !_N_MenuLI.checked : true;//改变当前选项
    MenuLI.className  = _N_MenuLI.type=="checkbox" ? (_N_MenuLI.checked ? 'selected' : '') : (_N_MenuLI.checked ? 'selected' : '');
        
    for(var i=0; i<_INPUT.length; i++){
        if(_INPUT[i].type=='checkbox'){
            _tempDate += _INPUT[i].name + ':' + (_INPUT[i].checked ? true : false) + ',';
            _INPUT[i].parentNode.getElementsByTagName("DIV")[0].className = _INPUT[i].checked ? 'icon' : 'icon_no';
        }
        else{//radio
            if(_INPUT[i].checked){
                _tempDate += _INPUT[i].name + ':' + _INPUT[i].value + ',';
                _INPUT[i].parentNode.getElementsByTagName("DIV")[0].className = 'icon_o';
            }
            else{
                _INPUT[i].parentNode.getElementsByTagName("DIV")[0].className = 'icon_no';
                _INPUT[i].parentNode.className = '';
            }
        }
    }
    this._Fun('' + (_tempDate ? _tempDate.substr(0,_tempDate.length-1) : null) + '');
    this.hiddenMenu();
}
_p._updatePos = function(){
    var rect       = im_wdkUtil.viewRect.get(window, true);
    var parentRect = im_wdkUtil.viewRect.get(this._rootElement, true);
    var MenuRect   = im_wdkUtil.viewRect.get(this._Menu, true);
    
    this._Menu.style.left = (this._rootElement.tagName=='BODY' ? (this._align=="left" ? 50 : (rect.x+rect.w-MenuRect.w-20) ) : parentRect.x) + 'px';
    this._Menu.style.top = (this._rootElement.tagName=='BODY' ? (rect.y+rect.h-MenuRect.h-20) : (parentRect.y-MenuRect.h)) + 'px';
}

function startGetMyIMStatus(imStatusUrl){
  if(imStatusUrl && im_global.variable.user_id)
    im_wdkUtil.createScript(imStatusUrl+"?query=onlinenum&sitid="+im_global.variable.siteid+"&uid="+im_global.variable.user_id+"&imsid="+im_global.variable.imsid);
}
function funChanage(data){
    im_global.temp.presenceFlash = document.getElementById("impresenceflash");
    if(im_global.temp.presenceFlash && im_global.temp.presenceFlash.SetUserSettings){
        im_global.temp.presenceFlash.SetUserSettings(data);
        if(im_global.cfg.DebugType==2) dzy_debug.debug("将要保存的用户配置："+data);
    }
}
function im_runPresenceStart() {/*获取flashservers*/
    var flashServersText = null;
    if(im_global.cfg.customparams["cache_serverinfo"])
        flashServersText = im_wdkUtil.GetCookie("flashservers");
    if(flashServersText)
        im_onGetFlashServer(flashServersText, '1', true);
    else{
        var getServerUrl = im_global.cfg.customparams["getserverurl"]?im_global.cfg.customparams["getserverurl"]:(im_global.variable.scriptPath+"/func/getflashserver.php");
        im_wdkUtil.createScript(getServerUrl+"?siteid="+im_global.variable.siteid+"&userid="+encodeURIComponent(im_global.variable.user_id)+"&resulttype=1&rand="+Math.random());
    }
    im_wdkUtil.Event.addEvent(window, "beforeunload", im_onBeforeUnload);
    im_wdkUtil.Event.addEvent(window, "unload", im_onUnload);

    wdkApplication = new WDK_IM_PACK.Application();
    wdkApplication.init();
    //
    if(typeof(im_global.cfg.not_showfloat_sites)!="undefined" && im_global.cfg.not_showfloat_sites){
        for(var i=0;i<im_global.cfg.not_showfloat_sites.length;i++){
            if(im_global.cfg.not_showfloat_sites[i].toLowerCase()==im_global.variable.siteid.toLowerCase()){
                im_global.cfg.customparams["enblebuddyentry"] = 0;
            }
        }
    }
    if(im_global.cfg.customparams["enblebuddyentry"]){
        im_myIMWindow = new  WDK_IM_PACK.IMWindow();
        im_myIMWindow.init();
    }

    im_notify_manager = new IMNotifyManager();
    im_chat_window_manager = new WDK_IM_PACK.ChatWindowManager();
    window.chatWindowManager = im_chat_window_manager;
    
    if(im_global.cfg.customparams["hiddenmode"]) return;
    if(im_global.cfg.customparams["entrytype"]=='toolbar' && im_global.cfg.customparams["enblebuddyentry"]){//
        im_toolbar = new WebIM.toolBar(im_chat_window_manager, im_myIMWindow, im_global.cfg.customparams['floatpos'], im_global.cfg.customparams["intact"]);
        im_toolbar.init(im_global.variable.user_id);
        im_toolBar_Menu = new WebIM.IM_Menu();
        im_toolBar_Menu.init(funChanage, "im_toolBar_Menu");//初始化
    }

    if(im_global.cfg.DebugType==1){
        im_logger = log4javascript.getLogger('xiaoneng');
        var popUpAppender = new log4javascript.PopUpAppender();
        im_logger.addAppender(popUpAppender);
    }
}
im_runPresenceStart();

//content of prompotwindow.js
//webchat flash will call this function when it receive a chat message
function im_onWebchatReceiveChatMsg(destuid, destnick, message, msgtype, chatid){
    msgtype = (typeof(msgtype)=="undefined")?"0":msgtype;
    if(promptwindow){
        var promptMsg;
        if(msgtype=="0")//common message
            promptMsg = destnick+": "+message;
        else if(msgtype=="1")//system message
            promptMsg = message;
        promptwindow.startPrompt(promptMsg, true);

        if(im_chat_window_manager){
            var chatWindow = im_chat_window_manager.getChatWindow(destuid);
            if(chatWindow){
                chatWindow.onReceiveMessage(message);
            }
        }
    }
}


//处理webchat flash收到消息的事件通知，包括对方打开聊窗等
function im_onWebchatReceiveEvent(destuid, destnick, eventname, eventcontent){
    if(promptwindow){
          promptwindow.startPrompt(eventcontent, true);
      }
}

//webchat flash will call this function when it get focus
function OnFlashFocus(){
     promptwindow.handleFocus();
}

//webchat flash will call this function when it lost focus
function OnFlashBlur(){
    promptwindow.handleBlur();
}

PromptWindow = function(){
    this.isfocus = false;
    this.isprompting = false;
    this.timerID = null;
    this.promptMsg = null;
    this.promptMsg2 = null;
    this.originTitle = document.title;
    this.counter = 0;
    this.autostop = true;  //当前页面如果为焦点,自动停止闪动
};

_p = PromptWindow.prototype;
_p.init = function(){
    var _this = this;
    var msie  = window.navigator.appName.indexOf("Microsoft") == 0;
    function _handleFocus(ev){
        _this.handleFocus(ev ||window.event);
    }
    function _handleBlur(ev){
        _this.handleBlur(ev || window.event);
    }

    //function __unload(ev){return beforePageClose();};
    if(msie){
        window.attachEvent("focus", _handleFocus, false);
        window.attachEvent("blur", _handleBlur, false);
        document.attachEvent("onfocusin", _handleFocus);
        document.attachEvent("onfocusout", _handleBlur);
    }else{
        window.addEventListener("focus", _handleFocus, false);
        window.addEventListener("blur", _handleBlur, false);
    }
};
_p.dispose = function(){

};

_p.handleFocus = function(ev){
    this.isfocus = true;
    
    //if(im_global.cfg.DebugType==2) dzy_debug.debug("获得焦点 "+this.isfocus);
    var presenceFlash = document.getElementById("impresenceflash");
    if(presenceFlash && presenceFlash.setPageFocus)
        presenceFlash.setPageFocus(true);
    if(this.autostop)
        this.stopPrompt();
}

_p.handleBlur = function(ev){
    var newvar = 1;
    this.isfocus = false;
    
    //if(im_global.cfg.DebugType==2) dzy_debug.debug("失去焦点 "+this.isfocus);
    var presenceFlash = document.getElementById("impresenceflash");
    if(presenceFlash && presenceFlash.setPageFocus)
        presenceFlash.setPageFocus(false);
}

_p.startPrompt = function(promptMsg, autostop){
    if(this.isprompting || this.isfocus)
        return;

    if(promptMsg && promptMsg.length>0){
        promptMsg = promptMsg.substring(0,15);
        this.promptMsg = "【"+promptMsg+"】"+" - "+this.originTitle;
        this.promptMsg2 = "";
        var l = Math.ceil(this.lenText(promptMsg)/2);
        for(var i=0; i<l; i++){
          this.promptMsg2+="　";
        }
        this.promptMsg2 = "【"+this.promptMsg2+"】"+" - "+this.originTitle;
    }

    if(autostop!=null)
        this.autostop = autostop;
    _this = this;
    var _changeWindowTitle = function(){ _this.changeWindowTitle(); };
    this.timerID = window.setInterval(_changeWindowTitle, 800);
    this.isprompting = true;
}
_p.lenText = function(str){
    var t = 0;
    for(var i=0;i<str.length;i++){
        if(str.charCodeAt(i)>255) t += 2;
        else t += 1;
    }
    return t;
}

_p.changeWindowTitle = function(){
    this.counter++;
    if(this.counter%2==0)
       //document.title = this.originTitle;
       document.title = this.promptMsg2;
    else
       document.title = this.promptMsg;
    try{
      if(top!=self){
          if(this.counter%2==0)
          //top.document.title = this.originTitle;
          top.document.title = this.promptMsg2;
        else
          top.document.title = this.promptMsg;
      }
  }
  catch(e){
  }
}

_p.stopPrompt = function(){
    if(!this.isprompting)
        return;
    
    window.clearInterval(this.timerID);
    this.timerID = null;
    this.counter = 0;
    document.title = this.originTitle;
    this.isprompting = false;
    try{
        if(top!=self)
            top.document.title = this.originTitle;
    }
    catch(e){
    }
}

im_flashGoUrl = null;
//called by buddylist Falsh
function setMyClientID(flashGoUrl){
     im_flashGoUrl  = flashGoUrl;
}

var promptwindow = null;
if(typeof(promptwindow)=="undefined" || !promptwindow){
  promptwindow = new PromptWindow();
    promptwindow.init();
}

//im_openWebchatWindow(432143, "fdsafdsafds");