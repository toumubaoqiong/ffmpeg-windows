
#include <string.h>